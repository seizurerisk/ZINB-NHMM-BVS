library(encryptr)

# First, request the decryption password by following instructions in the README.

# decrypt toy_example -----------------------------------------------------

setwd('toy_example')

decrypt_file('FB_SourceFunctions.cpp.encryptr.bin', 'FB_SourceFunctions.cpp')
decrypt_file('NBMCMC.R.encryptr.bin', 'NBMCMC.R')
decrypt_file('PG_SourceFunctions.R.encryptr.bin', 'PG_SourceFunctions.R')

# decrypt simulation_code -------------------------------------------------

setwd('../simulation_code/Source Files')

decrypt_file('FB.cpp.encryptr.bin', 'FB.cpp')
decrypt_file('NBMCMC.R.encryptr.bin', 'NBMCMC.R')
decrypt_file('NBMCMC_AIC_BIC.R.encryptr.bin', 'NBMCMC_AIC_BIC.R')
decrypt_file('NBMCMC_DIC.R.encryptr.bin', 'NBMCMC_DIC.R')
decrypt_file('NBMCMC_sensitivity.R.encryptr.bin', 'NBMCMC_sensitivity.R')
decrypt_file('SourceFunctions.R.encryptr.bin', 'SourceFunctions.R')
decrypt_file('SourceFunctions_sensitivity.R.encryptr.bin', 'SourceFunctions_sensitivity.R')