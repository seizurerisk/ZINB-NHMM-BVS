# This file reproduces simulation study results for the scalability
# investigation, described in the last paragraph of Section 3.3 of the
# main text.


# Simulation --------------------------------------------------------------

source('SourceFunctions.R')
source('NBMCMC.R')
library(gtools)
library(abind)
library(BayesLogit)
library(MASS)
library(coda)
library(knitr)
library(ZIM)
library(mvtnorm)
library(doSNOW)
library(caret)
library(Rcpp)
sourceCpp('FB.cpp')

c1 <- makeCluster(20)
registerDoSNOW(c1)

# Main params
K = 3
N = 100
p = 50

# ZINB Parameters
phi = c(3, 8, 15)
sims = 20
h_beta_store = c(rep(2,4), rep(3,4), rep(5,4), rep(10,4), rep(20, 4))

# Simulate data
X = list()
Y = list()
true_xi = list()

run.mc.sim <- function(A, num.iters = 50) {
  
  # number of possible states
  num.states <- nrow(A)
  
  # stores the states X_t through time
  states <- numeric(num.iters)
  
  # initialize variable for first state 
  states[1] <- sample(1:3, 1, prob = c(0.9, 0.08, 0.02))
  
  for(t in 2:num.iters) {
    
    # probability vector to simulate next state X_{t+1}
    p  <- A[states[t-1], ,t-1]
    
    ## draw from multinomial and determine state
    states[t] <-  which(rmultinom(1, 1, p) == 1)
  }
  return(states)
}

seed_store = 1:20
myresults <- foreach(current_sim = 1:sims, .packages = c('abind', 'ZIM','mvtnorm','msm','MASS','coda','BayesLogit','gtools','caret', 'Rcpp'), 
                     .combine = 'rbind', .multicombine = TRUE, .verbose = TRUE, .noexport = "FB_ADS") %dopar% { 
                       sourceCpp('FB.cpp')
                       set.seed(seed_store[current_sim])
                       
                       Ti = sample(100:110, 100, replace = T)
                       for (i in 1:N){
                         sex = rep(sample(0:1, 1), Ti[i])
                         age = rep(0, Ti[i])
                         motor = rep(0, Ti[i])
                         compliance = rep(0, Ti[i])
                         compliance_prob = runif(1, min = 0.2, max = 0.8)
                         duration = rep(0, Ti[i])
                         trigger = rep(0, Ti[i])
                         menstrual = rep(0, Ti[i])
                         
                         for (t in 1:Ti[i]){
                           if (t == 1){
                             age[1] = sample(30:23725, 1) /(365 * 65)
                           } else{
                             age[t] = age[t-1] + 1/(365 * 65)
                           }
                           
                           motor[t] = sample(0:5, 1)
                           compliance[t] = rbinom(1,1,prob = c(1-compliance_prob, compliance_prob))
                           
                           if (runif(1) > 0.5){
                             duration[t] = sample(2:3600, 1) /3600
                             trigger_prob = runif(1, min = 0.2, max = 0.8)
                             trigger[t] = rbinom(1,1,prob = c(1-trigger_prob, trigger_prob))
                           }
                         }
                         
                         if (sex[1] == 1){
                           start = sample(1:30,1)
                           if (start < Ti[i]){
                             dur = sample(4:6,1)
                             menstrual[start] = 1
                             while(dur > 0){
                               menstrual[start + dur] = 1
                               dur = dur - 1
                             }
                           }
                           
                           while(start + 37 < Ti[i]){
                             start = start + 30
                             menstrual[start] = 1
                             dur = sample(4:6,1)
                             while(dur > 0){
                               menstrual[start + dur] = 1
                               dur = dur - 1
                             }
                           }
                         }
                         
                         noise = matrix(rnorm(43 * Ti[i], 0, 1), nrow = Ti[i], ncol = 43)
                         cov = cbind(sex, age, motor, compliance, duration, trigger, menstrual + rnorm(Ti[i], 1, 1), noise)
                         X[[i]] = matrix(cov, nrow = Ti[i], ncol = 50)
                       }
                       
                       p <- ncol(X[[1]])
                       beta = array(0, c(K, K, p))
                       
                       beta[1,1,c(1,2,3,4,5,6,7)] = 3.5
                       beta[1,2,c(1,2,3)] = 2.9
                       beta[2,1,c(2,3,7)] = 2.4
                       beta[2,2,c(3,7)] = 3.0
                       beta[3,1,c(4,7)] = -2.9
                       beta[3,2,c(4,7)] = -2.5
                       
                       beta_reg = matrix(0, nrow = K, ncol = p)
                       beta_reg[,1:7] = rbind(c(-0.7,-0.8,-0.8,0,-0.8,-0.7,-0.7),
                                              c(-0.4,0,0,-0.4,0,-0.7,-0.6),
                                              c(0,-0.5,0,-0.5,0.5,0.4,0))
                       
                       tempx = c()
                       for(i in 1:N){
                         # Transition Matrix
                         A = array(NA, c(K, K, Ti[i]-1))     # (because for Ti[i] time points, there are (Ti[i]-1) transitions)
                         for (kprime in 1:K){
                           
                           # Transition probabilities for k=1,...(K-1)
                           for (k in (1:K)[-K]){
                             tmp = rep(0, Ti[i]-1)
                             for (ell in 1:K){
                               tmp = tmp + exp(X[[i]][1:(Ti[i]-1),] %*% beta[kprime,ell,])
                             }
                             A[kprime,k,] = exp(X[[i]][1:(Ti[i]-1),] %*% beta[kprime,k,]) / tmp
                           }
                           
                           # Transition probability for k=K
                           A[kprime,K,] = 1 / tmp
                         }
                         
                         true_xi[[i]] = run.mc.sim(A, num.iters = Ti[i])
                         Y[[i]] = rep(0, Ti[i])
                         
                         for(t in 1:Ti[i]){
                           pi = exp(X[[i]][t,]%*%beta_reg[true_xi[[i]][t],])/(1+exp(X[[i]][t,]%*%beta_reg[true_xi[[i]][t],]))
                           
                           mu = phi[true_xi[[i]][t]] * pi / (1-pi)
                           Y[[i]][t] = ZIM::rzinb(n = 1, k = phi[true_xi[[i]][t]], lambda = mu, omega = c(0.7, 0.05, 0.01)[true_xi[[i]][t]])
                           tempx = rbind(tempx, (c(true_xi[[i]][t], pi)))
                         }
                       }
                       
                       p1 = mean(tempx[which(tempx[,1] == 1),2])
                       p2 = mean(tempx[which(tempx[,1] == 2),2])
                       p3 = mean(tempx[which(tempx[,1] == 3),2])
                       true_psi1_store = p1
                       true_psi2_store = p2
                       true_psi3_store = p3
                       (true_mean1_store = p1*phi[1]/(1-p1))
                       (true_mean2_store = p2*phi[2]/(1-p2))
                       (true_mean3_store = p3*phi[3]/(1-p3))
                       
                       Trange = c(mean(c(true_mean1_store, true_mean2_store)), 
                                  mean(c(true_mean2_store, true_mean3_store)))
                       
                       g_rho = 1
                       h_rho = 20
                       g_beta = 1
                       h_beta = h_beta_store[current_sim]
                       c = 1
                       d = 1
                       e = 0.01
                       f = 0.01
                       qvec = c(1,1,1)
                       
                       tryCatch({
                         start_time = Sys.time()
                         burnin = 15000
                         maxiter = 30000 
                         results = NB_EPI_MCMC(X = X, Y = Y, maxiter = maxiter, K = K, Trange = Trange,
                                               c = c, d = d, e = e, f = f, burnin = burnin,
                                               g_beta = g_beta, h_beta = h_beta, g_rho = g_rho, h_rho = h_rho, 
                                               qvec = qvec)
                         end_time = Sys.time()
                         cat('NB MCMC time: ', end_time - start_time, '\n')
                         time_store = end_time - start_time
                         
                         list(results, time_store, unlist(true_xi))
                       }, error = function(e){cat("Error:", conditionMessage(e), "\n"); 0})
                     }

stopCluster(c1)
save.image(file = "Sim_1_scalability_data.RData")

# Results -----------------------------------------------------------------

load("Sim_1_scalability_data.RData")

set.seed(0)
i = 15
beta = array(0, c(K, K, p))
beta[1,1,c(1,2,3,4,5,6,7)] = 3.5
beta[1,2,c(1,2,3)] = 2.9
beta[2,1,c(2,3,7)] = 2.4
beta[2,2,c(3,7)] = 3.0
beta[3,1,c(4,7)] = -2.9
beta[3,2,c(4,7)] = -2.5

beta_reg = matrix(0, nrow = K, ncol = p)
beta_reg[,1:7] = rbind(c(-0.7,-0.8,-0.8,0,-0.8,-0.7,-0.7),
                       c(-0.4,0,0,-0.4,0,-0.7,-0.6),
                       c(0,-0.5,0,-0.5,0.5,0.4,0))
trueppi1 = (beta_reg != 0)
trueppi2 = (beta[,-K,] != 0)

results = myresults[i,1][[1]]
burnin = 15000
maxiter = 30000
post_phi = results[[1]]
if(sum(is.na(post_phi[1,])) > 0){
  maxiter = which(is.na(post_phi[1,]))[1] - 2
  burnin = ceiling(maxiter/2)
}

post_p_aux = results[[3]]
post_xi = results[[4]]
post_pi = results[[5]]
post_beta = results[[6]]
num_switch = results[[7]]
post_rho = results[[8]]
post_psi = results[[9]]
num_switch_2 = results[[10]]
num_switch_3 = results[[11]]
post_lambda = results[[12]]
errors = results[[13]]
post_gamma_1 = results[[14]]
post_gamma_2 = results[[15]]
ads_accept_1 = results[[16]]
ads_accept_2 = results[[17]]

phi_m = rowMeans(post_phi[,burnin:maxiter])
p_aux_m = rowMeans(post_p_aux[,burnin:maxiter])
pi_m = rowMeans(post_pi[,burnin:maxiter])
psi_m = rowMeans(post_psi[,burnin:maxiter])
lambda_m = rowMeans(post_lambda[,burnin:maxiter])

betas_m = matrix(0, K, p)
templist = matrix(NA, length(burnin:maxiter))
for(k in 1:K){
  for(cp in 1:p){
    templist = matrix(NA, length(burnin:maxiter))
    for(iter in burnin:maxiter){
      templist[iter-burnin+1] = post_rho[[iter]][k,cp]
    }
    templist = c(templist[which(templist != 0)],0)
    betas_m[k,cp] = mean(templist)
  }
}

ppi2 = array(0, c(K,K-1,p))
for(iter in burnin:maxiter){
  ppi2 = ppi2 + post_gamma_2[[iter]]
}
ppi2 = ppi2/length(burnin:maxiter)

ppi1 = matrix(0, K, p)
for(iter in burnin:maxiter){
  ppi1 = ppi1 + post_gamma_1[[iter]]
}
ppi1 = ppi1/length(burnin:maxiter)

avg_beta = array(0, c(K,K,p))
templist = rep(NA, length(burnin:maxiter))
for(ind in 1:(K * K * p)){
  for(iter in burnin:maxiter){
    templist[iter-burnin+1] = post_beta[[iter]][ind]
  }
  templist = c(templist[which(templist != 0)],0)
  avg_beta[ind] = mean(templist)
}

post_mode_xi = list()
for(pat in 1:N){
  post_mode_xi[[pat]] = apply(post_xi[[pat]], 2, which.max)
}

# Transitions
ppi2 = 1*(ppi2 >= 0.5)
sum(ppi2) # '# selected'
sum((ppi2 == 0) & (trueppi2 == 1))/(sum((ppi2 == 0) & (trueppi2 == 1)) + sum((ppi2 == 1) & (trueppi2 == 1))) # FNR
sum((ppi2 == 1) & (trueppi2 == 0))/(sum((ppi2 == 1) & (trueppi2 == 0)) + sum((ppi2 == 0) & (trueppi2 == 0))) # FPR
TP = sum((ppi2 == 1) & (trueppi2 == 1))
FP = sum((ppi2 == 1) & (trueppi2 == 0))
TN = sum((ppi2 == 0) & (trueppi2 == 0))
FN = sum((ppi2 == 0) & (trueppi2 == 1))
prec = TP/(TP + FP)  # prec
sens = TP/(TP+FN)  # sens
TN/(TN+FP)  # spec
2*prec*sens/(prec+sens)  # F1 score

# Emissions
ppi1 = 1*(ppi1 >= 0.5)
sum(ppi1) # '# selected'
sum((ppi1 == 0) & (trueppi1 == 1))/(sum((ppi1 == 0) & (trueppi1 == 1)) + sum((ppi1 == 1) & (trueppi1 == 1))) # FNR
sum((ppi1 == 1) & (trueppi1 == 0))/(sum((ppi1 == 1) & (trueppi1 == 0)) + sum((ppi1 == 0) & (trueppi1 == 0))) # FPR
TP = sum((ppi1 == 1) & (trueppi1 == 1))
FP = sum((ppi1 == 1) & (trueppi1 == 0))
TN = sum((ppi1 == 0) & (trueppi1 == 0))
FN = sum((ppi1 == 0) & (trueppi1 == 1))
prec = TP/(TP + FP)  # prec
sens = TP/(TP+FN)  # sens
TN/(TN+FP)  # spec
2*prec*sens/(prec+sens)  # F1 score

# Latent States
TP = rep(NA, 3)
FP = rep(NA, 3)
TN = rep(NA, 3)
FN = rep(NA, 3)
current_confusion = as.matrix(confusionMatrix(as.factor(unlist(post_mode_xi)), as.factor(unname(myresults[i,3])[[1]])))
for(k in 1:K){
  TP[k] = current_confusion[k,k]
  FP[k] = sum(current_confusion[k,-k])
  TN[k] = sum(current_confusion[-k,-k])
  FN[k] = sum(current_confusion[-k,k])
}

mean((TP+TN)/(TP + FP + TN + FN))
prec = mean(TP/(TP + FP)) # prec
sens = mean(TP/(TP + FN)) # sens
spec = mean(TN/(TN + FP)) # spec
2*prec*sens/(prec+sens)  # F1 score

myresults[i,2] # Compute time (8.7 hrs)
