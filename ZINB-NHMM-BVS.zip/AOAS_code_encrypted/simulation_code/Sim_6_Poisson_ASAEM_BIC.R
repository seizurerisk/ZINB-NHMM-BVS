# This file reproduces simulation study results for the ASA-EM, BIC rows
# in Tables 4 and 5: Poisson simulation study for comparison of proposed
# approach (ZINB-NHMM-BVS) to ASA-EM, in terms of classification of 
# covariate selection and latent states.


# Simulation --------------------------------------------------------------

source('SourceFunctions.R')
source('NBMCMC.R')
library(gtools)
library(abind)
library(BayesLogit)
library(MASS)
library(coda)
library(knitr)
library(msm)
library(ZIM)
library(mvtnorm)
library(doSNOW)
library(parallel)
library(caret)
library(Rcpp)
library(depmixS4pp)
sourceCpp('FB.cpp')

c1 <- makeCluster(1)
registerDoSNOW(c1)

# Main params
K = 2
N = 100
p = 15
M = 24
sims = 36

# Simulate data
X = list()
Y = list()
true_xi = list()

simulated_annealing = function (epochs = 3, estat = 3, family = gaussian(), fparam, 
                                isobsbinary, MIC = stats::BIC, SIC = stats::AIC, fobserved, 
                                ranges, ns, initpr, data, a.prior.em, b.prior.em, a.post.em, 
                                wcrit, a.Q.prior, b.Q.prior, X.min, X.max, a.maxit.prior = 20, 
                                b.maxit.prior = 0.1, prior.inclusion, s2.post.maxit, col.rate.maxit, 
                                tmin, temp, dt, p_id, seed) 
{
  if (family$family == "binomial") {
    osv = paste("cbind(", fobserved[1], ",", 
                fobserved[2], ")")
  }
  else osv = fobserved
  maxit = a.maxit.prior
  stm = proc.time()
  set.seed(seed, kind = NULL, normal.kind = NULL)
  print(paste("begin SA methasearch procedure", "with EM local search greedy updates for each neighbourhood!"))
  tcur = temp
  n.obs.em = 0
  sum.obs.em = 0
  n.obs.maxit = 0
  sum.obs.maxit = 0
  n.obs.k = 0
  sum.obs.k = 0
  post.inclusion = prior.inclusion
  tid = 0
  ii = 1
  globcrit = array(2, data = Inf)
  fm = NULL
  varcur.obs = rbinom(n = length(fparam), size = 1, prob = 0.5)
  varcur.trs = rbinom(n = length(fparam), size = 1, prob = 0.5)
  N = length(varcur.obs)
  covobs = fparam[which(varcur.obs == 1)]
  covtrans = fparam[which(varcur.trs == 1)]
  obsconst = 0
  transconst = 0
  formula = as.formula(paste(osv, " ~ ", obsconst, ifelse(test = length(covobs) > 
                                                            0, " + ", ""), paste(covobs, collapse = " + ")))
  transition = as.formula(paste(" ~ ", transconst, ifelse(test = length(covtrans) > 
                                                            0, " + ", ""), paste(covtrans, collapse = " + ")))
  if (length(covtrans) > 0 && length(covobs) > 0) {
    formula = as.formula(paste(osv, " ~ ", "0 + ",
                               paste(covobs, collapse = " + ")))
    transition = as.formula(paste(" ~ ", "0 + ",
                                  paste(covtrans, collapse = " + ")))
    mod = depmix(response = formula, data = data, transition = transition, 
                 nstates = ns, instart = initpr, family = family)
  }
  else {
    if (length(covtrans) > 0 && length(covobs) == 0) {
      transition = as.formula(paste(" ~ ", "0 + ",
                                    paste(covtrans, collapse = " + ")))
      mod = depmix(response = as.formula(paste(osv, " ~ ", 
                                               "0")), data = data, transition = transition, 
                   nstates = ns, instart = initpr, family = family)
    }
    if (length(covtrans) == 0 && length(covobs) > 0) {
      formula = as.formula(paste(osv, " ~ ", "0 + ",
                                 paste(covobs, collapse = " + ")))
      mod = depmix(response = formula, data = data, nstates = ns, 
                   instart = initpr, family = family)
    }
    if (length(covtrans) == 0 && length(covobs) == 0) {
      mod = depmix(response = as.formula(paste(osv, " ~ ", 
                                               "0")), data = data, nstates = ns, instart = initpr, 
                   family = family)
    }
  }
  curn = rnbinom(n = 1, size = a.prior.em + sum.obs.em, prob = 1 - 
                   1/(1 + b.prior.em + n.obs.em))
  em.params = em.control(maxit = curn, random.start = TRUE)
  capture.output({
    withRestarts(tryCatch(capture.output({
      fm = fit(mod, emcontrol = em.params)
    }), error = function(e) {
      invisible(e)
    }), abort = function() {
      fm = mod
      onerr = TRUE
    })
  })
  globcrit[1] = MIC(fm)
  globcrit[2] = SIC(fm)
  varglob.obs = varcur.obs
  varglob.trs = varcur.trs
  glmod = fm
  curcrit = globcrit
  for (epoch in 1:epochs) {
    print(paste0("start epoch ", epoch))
    tcur = temp
    while (tcur >= tmin) {
      if (tid%%p_id == 0) {
        n.obs.maxit = 0
        sum.obs.maxit = 0
        maxit = rnbinom(n = 1, size = a.maxit.prior + 
                          sum.obs.maxit, prob = 1 - 1/(1 + b.maxit.prior + 
                                                         n.obs.maxit))
        print(paste(ii, " iterations completed up to now"))
        print(paste("MIC.cur.glob = ", globcrit[1]))
        print(paste("aneal to temp = ", tcur, " proceed with this temp. for", 
                    maxit, "iterations"))
      }
      for (i in 1:maxit) {
        withRestarts(tryCatch({
          varcurb.obs = varcur.obs
          varcurb.trs = varcur.trs
          K = rbinom(n = 1, size = N, prob = rbeta(n = 1, 
                                                   shape1 = (a.Q.prior + sum.obs.k), shape2 = (b.Q.prior + 
                                                                                                 N * n.obs.k - sum.obs.k)))
          chids = sample.int(n = length(varcur.obs), 
                             size = K, replace = F)
          varcur.obs[chids] = rbinom(n = K, size = 1, 
                                     prob = post.inclusion[chids, 1]/sum(post.inclusion[, 
                                                                                        1]))
          varcur.trs[chids] = rbinom(n = K, size = 1, 
                                     prob = post.inclusion[chids, 2]/sum(post.inclusion[, 
                                                                                        2]))
          covobs = fparam[which(varcur.obs == 1)]
          covtrans = fparam[which(varcur.trs == 1)]
          obsconst = 0
          transconst = 0
          formula = as.formula(paste(osv, " ~ ", 
                                     obsconst, ifelse(test = length(covobs) > 
                                                        0, " + ", ""), paste(covobs, 
                                                                             collapse = " + ")))
          transition = as.formula(paste(" ~ ", 
                                        transconst, ifelse(test = length(covtrans) > 
                                                             0, " + ", ""), paste(covtrans, 
                                                                                  collapse = " + ")))
          if (length(covtrans) > 0 && length(covobs) > 
              0) {
            formula = as.formula(paste(osv, " ~ ", "0 + ",
                                       paste(covobs, collapse = " + ")))
            transition = as.formula(paste(" ~ ", "0 + ",
                                          paste(covtrans, collapse = " + ")))
            mod = depmix(response = formula, data = data, 
                         transition = transition, nstates = ns, 
                         instart = initpr, family = family)
          }
          else {
            if (length(covtrans) > 0 && length(covobs) == 
                0) {
              transition = as.formula(paste(" ~ ", "0 + ",
                                            paste(covtrans, collapse = " + ")))
              mod = depmix(response = as.formula(paste(osv, 
                                                       " ~ ", "0")), data = data, 
                           transition = transition, nstates = ns, 
                           instart = initpr, family = family)
            }
            if (length(covtrans) == 0 && length(covobs) > 
                0) {
              formula = as.formula(paste(osv, " ~ ", "0 + ",
                                         paste(covobs, collapse = " + ")))
              mod = depmix(response = formula, data = data, 
                           nstates = ns, instart = initpr, family = family)
            }
            if (length(covtrans) == 0 && length(covobs) == 
                0) {
              mod = depmix(response = as.formula(paste(osv, 
                                                       " ~ ", "0")), data = data, 
                           nstates = ns, instart = initpr, family = family)
            }
          }
          fmb = fm
          onerr = FALSE
          curn = rnbinom(n = 1, size = a.prior.em + sum.obs.em, 
                         prob = 1 - 1/(1 + b.prior.em + n.obs.em))
          em.params = em.control(maxit = curn, random.start = TRUE)
          capture.output({
            withRestarts(tryCatch(capture.output({
              fm = fit(mod, emcontrol = em.params)
            }), error = function(e) {
              invisible(e)
            }), abort = function() {
              varcur.obs = varcurb.obs
              varcur.trs = varcurb.trs
              fm = fmb
              onerr = TRUE
            })
          })
          ii = ii + 1
          if (MIC(fm) < globcrit[1]) {
            print(paste("update global optimum with new global MIC = ", 
                        MIC(fm)))
            globcrit[1] = MIC(fm)
            globcrit[2] = SIC(fm)
            glmod = fm
            varglob.obs = varcur.obs
            varglob.trs = varcur.trs
            if (epoch < estat) {
              n.obs.em = (n.obs.em + 1)
              sum.obs.em = (sum.obs.em + curn)
              sum.obs.k = sum.obs.k + K
              n.obs.k = n.obs.k + 1
              n.obs.maxit = (n.obs.maxit + 1)
              sum.obs.maxit = sum.obs.maxit + maxit
              post.inclusion[, 1] = prior.inclusion[, 
                                                    1] + varglob.obs
              post.inclusion[, 2] = prior.inclusion[, 
                                                    2] + varglob.trs
            }
          }
          if (((MIC(fm) - curcrit[1])) - (tcur) <= log(runif(n = 1, 
                                                             min = 0, max = 1)) && !onerr) {
            curcrit[1] = MIC(fm)
            curcrit[2] = SIC(fm)
            if (epoch < estat && tcur < 1) {
              n.obs.em = (n.obs.em + 1)
              sum.obs.em = (sum.obs.em + curn)
              sum.obs.k = sum.obs.k + K
              n.obs.k = n.obs.k + 1
              n.obs.maxit = (n.obs.maxit + 1)
              sum.obs.maxit = sum.obs.maxit + maxit
              post.inclusion[, 1] = prior.inclusion[, 
                                                    1] + varcur.obs
              post.inclusion[, 2] = prior.inclusion[, 
                                                    2] + varcur.trs
            }
          }
          else {
            varcur.obs = varcurb.obs
            varcur.trs = varcurb.trs
          }
        }), abort = function() {
          varcur.obs = varcurb.obs
          varcur.trs = varcurb.trs
          fm = fmb
          onerr = TRUE
        })
      }
      tcur = tcur * exp(-dt)
      tid = tid + 1
      n.obs.k = 0
      sum.obs.k = 0
    }
    print(paste(ii, " iterations completed in total"))
    print(paste(tcur, " is the final temperature"))
    print(paste("MIC.cur.glob = ", globcrit[1]))
  }
  etm = proc.time()
  tt = (etm[3] - stm[3]) * 1000
  return(list(model = glmod, vars.obs = varglob.obs, vars.trs = varglob.trs, 
              time = (tt)))
}

run.mc.sim <- function(A, num.iters = 50) {
  
  # number of possible states
  num.states <- nrow(A)
  
  # stores the states X_t through time
  states <- numeric(num.iters)
  
  # initialize variable for first state 
  states[1] <- sample(1:2, 1, prob = c(0.9, 0.1))
  
  for(t in 2:num.iters) {
    
    # probability vector to simulate next state X_{t+1}
    p  <- A[states[t-1], ,t-1]
    
    ## draw from multinomial and determine state
    states[t] <-  which(rmultinom(1, 1, p) == 1)
  }
  return(states)
}

select_depmix =	function(data,epochs = 3, estat = 3, MIC = stats::AIC,SIC =stats::BIC,family = gaussian(),fparam,isobsbinary,prior.inclusion,fobserved = fobserved,ranges = 1,ns =3,initpr = c(0,1,0),a.prior.em = list(min = 100,max = 200), b.prior.em = list(min = 1,max = 10), a.post.em = 10,wcrit = 1,a.Q.prior = list(min = 5, max = 5), b.Q.prior = list(min =15,max = 15), X.min = 3, X.max = 10, a.maxit.prior  = list(min = 15, max = 35) ,b.maxit.prior  = list(min = 2, max = 2) ,s2.post.maxit = 3 ,col.rate.maxit = list(min = 0.97, max = 0.99),tmin = list(min = 0.0000005, max = 0.05),temp = list(min = 20000,max = 2000000000),dt = list(min = 2, max = 6) ,p_id = 1,seeds = runif(4,1,1000),cores = 4, M = 1) {
  params = NULL
  for(i in 1:cores)
  {
    params[[i]]=list(epochs = epochs, estat = estat,MIC = MIC, SIC = SIC, fparam = fparam,family = family,isobsbinary = isobsbinary,prior.inclusion = prior.inclusion,fobserved = fobserved,ranges = ranges,ns = ns,initpr = initpr,data = data,a.prior.em = runif(n = 1,a.prior.em$min,a.prior.em$max), b.prior.em = runif(n = 1,b.prior.em$min,b.prior.em$max), a.post.em = a.post.em,wcrit = wcrit,a.Q.prior = runif(n = 1, a.Q.prior$min, a.Q.prior$max), b.Q.prior = runif(n = 1, b.Q.prior$min, b.Q.prior$max), X.min = X.min, X.max = X.max,a.maxit.prior  = runif(n = 1,a.maxit.prior$min,a.maxit.prior$max) ,b.maxit.prior  =  runif(n = 1,b.maxit.prior$min,b.maxit.prior$max) ,s2.post.maxit = s2.post.maxit ,col.rate.maxit = runif(n=1,col.rate.maxit$min,col.rate.maxit$max),tmin = runif(n = 1,tmin$min, tmin$max),temp = runif(n = 1,temp$min,temp$max),dt = runif(n = 1,dt$min, dt$max) ,p_id = p_id,seed = seeds[i])
    
    #params[[i]]=list(MIC = stats::AIC,SIC =stats::BIC,fparam = fparam,isobsbinary = c(0,0,rep(1,length(fparam))),prior.inclusion = array(1,c(length(fparam),2)),fobserved = fobserved,ranges = 1,ns = ns,initpr = c(0,1,0),data = X,a.prior.em = runif(n = 1,min = 100,max = 200), b.prior.em = runif(n = 1,min = 1,max = 10), a.post.em = 10,wcrit = 1,a.Q.prior = 5, b.Q.prior = 15, X.min = 3, X.max = 10,a.maxit.prior  = runif(n = 1,min = 15, max = 35) ,b.maxit.prior  = 2 ,s2.post.maxit = 3 ,col.rate.maxit = runif(n=1,min = 0.97, max = 0.99),tmin = runif(n = 1,min = 0.0000005, max = 0.05),temp = runif(n = 1,min = 20000,max = 2000000000),dt = runif(n = 1,min = 2, max = 6) ,p_id = 1,seed = runif(1,1,1000))
  }
  
  results = mclapply(FUN = function(x) do.call(simulated_annealing,x),X = params,mc.cores = cores)
  best.mic = -1
  best.sic = -1
  
  res.aic = NULL
  res.bic = NULL
  for(i in 1:M)
  {
    if(length(results[[i]])>1)
    { 
      if(best.mic ==-1)
      {
        best.mic = i
        best.sic = i
      }
      res.aic = c(res.aic,AIC(results[[i]]$model))
      res.bic = c(res.bic,BIC(results[[i]]$model))
      if(MIC(results[[i]]$model)<MIC(results[[best.mic]]$model))
        best.mic = i 
      if(SIC(results[[i]]$model)<SIC(results[[best.sic]]$model))
        best.sic = i 
    }
    else
    {
      res.aic =c(res.aic,Inf)
      res.bic = c(res.bic,Inf)
    }
  }
  
  return(list(best.mic=best.mic, best.sic = best.sic, bics = res.bic, aics = res.aic, results = results))
  
}

seed_store = 106:(106+sims-1)
myresults <- foreach(current_sim = 1:sims, .packages = c('abind', 'ZIM','mvtnorm','msm','MASS','coda','BayesLogit','gtools','caret', 'Rcpp','depmixS4','depmixS4pp','parallel'), 
                     .combine = 'rbind', .multicombine = TRUE, .verbose = TRUE, .noexport = "FB_ADS", .errorhandling = "remove") %dopar% { 
                       set.seed(seed_store[current_sim])
                       
                       Ti = sample(100:110, 100, replace = T)
                       for (i in 1:N){
                         sex = rep(sample(0:1, 1), Ti[i])
                         age = rep(0, Ti[i])
                         motor = rep(0, Ti[i])
                         compliance = rep(0, Ti[i])
                         compliance_prob = runif(1, min = 0.2, max = 0.8)
                         duration = rep(0, Ti[i])
                         trigger = rep(0, Ti[i])
                         menstrual = rep(0, Ti[i])
                         
                         for (t in 1:Ti[i]){
                           if (t == 1){
                             age[1] = sample(15000:23725, 1) /(365 * 65)
                           } else{
                             age[t] = age[t-1] + 1/(365 * 65)
                           }
                           
                           motor[t] = sample(0:5, 1)
                           compliance[t] = rbinom(1,1,prob = c(1-compliance_prob, compliance_prob))
                           
                           if (runif(1) > 0.5){
                             duration[t] = sample(2600:3600, 1) /3600
                             trigger_prob = runif(1, min = 0.2, max = 0.8)
                             trigger[t] = rbinom(1,1,prob = c(1-trigger_prob, trigger_prob))
                           }
                         }
                         
                         if (sex[1] == 1){
                           start = sample(1:30,1)
                           if (start < Ti[i]){
                             dur = sample(4:6,1)
                             menstrual[start] = 1
                             while(dur > 0){
                               menstrual[start + dur] = 1
                               dur = dur - 1
                             }
                           }
                           
                           while(start + 37 < Ti[i]){
                             start = start + 30
                             menstrual[start] = 1
                             dur = sample(4:6,1)
                             while(dur > 0){
                               menstrual[start + dur] = 1
                               dur = dur - 1
                             }
                           }
                         }
                         
                         cov = cbind(sex, 1.2*age, motor, compliance, 2*duration, trigger, menstrual + rnorm(Ti[i], 1, 1),
                                     rnorm(Ti[i], 1, 1), rnorm(Ti[i], 1, 1), rnorm(Ti[i], 1, 1), rnorm(Ti[i], 1, 1), rnorm(Ti[i], 1, 1), rnorm(Ti[i], 1, 1),
                                     rnorm(Ti[i], 1, 1), rnorm(Ti[i], 1, 1))
                         X[[i]] = matrix(cov, Ti[i], 15)
                       }
                       
                       p <- ncol(X[[1]])
                       beta = array(0, c(K, K, p))
                       
                       beta[1,1,c(5,7)] = 4
                       beta[1,1,c(2,3)] = -1
                       beta[2,1,c(2,3)] = 1
                       beta[2,1,c(5,7)] = -1.8
                       
                       beta_reg = rbind(c(-0.7,-0.7,0,0,-4,0,-0.7,0,0,0,0,0,0,0,0),
                                        c(0.5,-0.4,0,0,0.7,0,0.5,0,0,0,0,0,0,0,0))
                       
                       tempx = c()
                       for(i in 1:N){
                         # Transition Matrix
                         A = array(NA, c(K, K, Ti[i]-1))     # (because for Ti[i] time points, there are (Ti[i]-1) transitions)
                         for (kprime in 1:K){
                           
                           # Transition probabilities for k=1,...(K-1)
                           for (k in (1:K)[-K]){
                             tmp = rep(0, Ti[i]-1)
                             for (ell in 1:K){
                               tmp = tmp + exp(X[[i]][2:Ti[i],] %*% beta[kprime,ell,])
                             }
                             A[kprime,k,] = exp(X[[i]][2:Ti[i],] %*% beta[kprime,k,]) / tmp
                           }
                           
                           # Transition probability for k=K
                           A[kprime,K,] = 1 / tmp
                         }
                         
                         true_xi[[i]] = run.mc.sim(A, num.iters = Ti[i])
                         Y[[i]] = rep(0, Ti[i])
                         
                         for(t in 1:Ti[i]){
                           pi = exp(X[[i]][t,]%*%beta_reg[true_xi[[i]][t],])
                           
                           Y[[i]][t] = rpois(n = 1, lambda = pi)
                           tempx = rbind(tempx, (c(true_xi[[i]][t], pi)))
                         }
                       }
                       Trange = c(1)
                       
                       p1 = mean(tempx[which(tempx[,1] == 1),2])
                       p2 = mean(tempx[which(tempx[,1] == 2),2])
                       true_psi1_store = p1
                       true_psi2_store = p2
                       true_mean1_store = p1
                       true_mean2_store = p2

                       myX = data.frame(do.call(rbind,X), unlist(Y))
                       colnames(myX) = c('Sex','Age','Motor','Compliance','Duration','Trigger','Menstrual', 'a','b','c',
                                         'd','e','f','g','h','Counts')
                       
                       M = 24
                       start_time = Sys.time()
                       tp_list = list()
                       ep_list = list()
                       results = select_depmix(epochs = 3,estat =3,
                                               MIC = stats::AIC, SIC =stats::BIC,
                                               data = myX, family = poisson(), fparam = colnames(myX)[-16], 
                                               fobserved = 'Counts', isobsbinary = c(1,0,0,1,0,1,0,0,0,0,0,0,0,0,0), 
                                               prior.inclusion = array(1,c(length(colnames(myX)[-16]),2)), ranges = 1,ns = 2,
                                               initpr =  c(0.9,0.1), seeds = sample(1:100, 100), cores = M, M = M)
                       end_time = Sys.time()
                       time_store = end_time - start_time
                       posts = depmixS4pp::posterior(results$results[[results$best.sic]]$model)
                       len = length(results$results)
                       for(id in 1:len){
                         if(length(results$results[[id]]) > 1){
                           tp_list[[id]] = results$results[[id]]$vars.trs
                           ep_list[[id]] = results$results[[id]]$vars.obs
                         } else{
                           tp_list[[id]] = 0
                           ep_list[[id]] = 0
                         }
                         
                       }
                       bestmod = results[[2]] # Choose best model by best SIC
                       
                       results1 = posts$state
                       post_mode_xi_1 = results1
                       
                       mymeans = c(mean(unlist(Y)[which(results1==1)]), mean(unlist(Y)[which(results1==2)]))
                       myorder1 = c(0,0)
                       myorder1[which(mymeans == max(mymeans))] = 2
                       myorder1[which(mymeans == min(mymeans))] = 1
                       
                       post_mode_xi_1[which(results1 == which(myorder1 == 1))] = 1
                       post_mode_xi_1[which(results1 == which(myorder1 == 2))] = 2
                       acc_store_1 = sum(post_mode_xi_1 == unlist(true_xi))/length(unlist(true_xi))
                       confusion_store_1 = as.matrix(confusionMatrix(as.factor(post_mode_xi_1), as.factor(unlist(true_xi))))
                       
                       rm(results)
                       
                       list(true_psi1_store, true_psi2_store, 
                            true_mean1_store, true_mean2_store, 
                            acc_store_1, confusion_store_1,
                            unlist(true_xi), post_mode_xi_1, 
                            tp_list, ep_list, bestmod, post_mode_xi_1, time_store)
                       
                     }

stopCluster(c1)
save.image(file = "Sim_6_Poisson_ASAEM_BIC_data.RData")

# Analyze results ---------------------------------------------------------

load("Sim_6_Poisson_ASAEM_BIC_data.RData")

beta = array(0, c(K, K, p))
beta[1,1,c(5,7)] = 4
beta[1,1,c(2,3)] = -1
beta[2,1,c(2,3)] = 1
beta[2,1,c(5,7)] = -1.8

beta_reg = rbind(c(-0.7,-0.7,0,0,-4,0,-0.7,0,0,0,0,0,0,0,0),
                 c(0.5,-0.4,0,0,0.7,0,0.5,0,0,0,0,0,0,0,0))

# Covariate selection
metrics = matrix(NA, nrow = 36, ncol = 14)
trueppi1 = (beta_reg[1,] != 0)
trueppi2 = (beta[1,1,] != 0)
temptable  = matrix(NA, nrow = M, ncol = 16)
for(num in 1:36){
  for(sim in 1:M){
    ppi2 = unname(myresults[num,9])[[1]][[sim]]
    temptable[sim,1] = K * (K-1) * sum(ppi2)
    temptable[sim,2] = (K * (K-1)*sum((ppi2 == 0) & (trueppi2 == 1))/(K * (K -1)*sum((ppi2 == 0) & (trueppi2 == 1)) + K * (K -1)*sum((ppi2 == 1) & (trueppi2 == 1))))
    temptable[sim,3] = (K * (K-1)*sum((ppi2 == 1) & (trueppi2 == 0))/(K * (K -1)*sum((ppi2 == 1) & (trueppi2 == 0)) + K * (K -1)*sum((ppi2 == 0) & (trueppi2 == 0))))
    TP = K * (K -1) * sum((ppi2 == 1) & (trueppi2 == 1))
    FP = K * (K -1) * sum((ppi2 == 1) & (trueppi2 == 0))
    TN = K * (K -1) * sum((ppi2 == 0) & (trueppi2 == 0))
    FN = K * (K -1) * sum((ppi2 == 0) & (trueppi2 == 1))
    temptable[sim,4] = TP/(TP+FN)  # sens
    temptable[sim,15] = prec = TP/(TP + FP)  # prec
    temptable[sim,5] = TN/(TN+FP)  # spec
    temptable[sim,6] = 2*prec*temptable[sim,4]/(prec+temptable[sim,4])  # f1
    
    ppi1 = unname(myresults[num,10])[[1]][[sim]]
    temptable[sim,7] = K * sum(ppi1)
    temptable[sim,8] = K * sum((ppi1 == 0) & (trueppi1 == 1))/(K*sum((ppi1 == 0) & (trueppi1 == 1)) + K*sum((ppi1 == 1) & (trueppi1 == 1)))
    temptable[sim,9] = K * sum((ppi1 == 1) & (trueppi1 == 0))/(K*sum((ppi1 == 1) & (trueppi1 == 0)) + K*sum((ppi1 == 0) & (trueppi1 == 0)))
    TP = K * sum((ppi1 == 1) & (trueppi1 == 1))
    FP = K * sum((ppi1 == 1) & (trueppi1 == 0))
    TN = K * sum((ppi1 == 0) & (trueppi1 == 0))
    FN = K * sum((ppi1 == 0) & (trueppi1 == 1))
    temptable[sim,10] = TP/(TP+FN)
    temptable[sim,16] = prec = TP/(TP + FP)  # prec
    temptable[sim,11] = TN/(TN+FP)
    temptable[sim,12] = 2*prec*temptable[sim,10]/(prec+temptable[sim,10])
    temptable[sim,13] = temptable[sim,2] + temptable[sim,3]
    temptable[sim,14] = temptable[sim,8] + temptable[sim,9]
  }
  id1 = id2 = unname(myresults[num,11])[[1]]
  metrics[num,1] = temptable[id1,1] # TP sel
  metrics[num,2] = temptable[id1,2] # TP FN
  metrics[num,3] = temptable[id1,3] # TP FP
  metrics[num,4] = temptable[id1,4] # TP sens
  metrics[num,5] = temptable[id1,5] # TP spec
  metrics[num,6] = temptable[id1,6] # TP f1
  metrics[num,7] = temptable[id2,7] # EP sel
  metrics[num,8] = temptable[id2,8] # EP FN
  metrics[num,9] = temptable[id2,9] # EP FP
  metrics[num,10] = temptable[id2,10] # EP sens
  metrics[num,11] = temptable[id2,11] # EP spec
  metrics[num,12] = temptable[id2,12] # EP f1
  metrics[num,13] = temptable[id1,15] # TP prec
  metrics[num,14] = temptable[id2,16] # EP prec
}

# This produces the 'ASA-EM, BIC' row of Table 4.
# Values 1-6 are # Selected, FNr, FPR, Sens, Spec, F1 of transitions
# Values 7-12 are # Selected, FNr, FPR, Sens, Spec, F1 of emissions
# Value 13 is Prec of transitions
# Value 14 is Prec of emissions
colMeans(metrics[1:30,], na.rm = TRUE)

# Latent states
ind = 1:36
m = length(ind)
K = 2
metrics = matrix(NA, nrow = 36, ncol = 5)
TP = rep(NA, K)
FP = rep(NA, K)
TN = rep(NA, K)
FN = rep(NA, K)
trueppi1 = (beta_reg[1,] != 0)
trueppi2 = (beta[1,1,] != 0)
for(index in 1:length(ind)){
  i = ind[index]
  current_confusion = unname(myresults[i,6])[[1]]
  TP = current_confusion[1,1]
  FP = current_confusion[1,2]
  TN = current_confusion[2,2]
  FN = current_confusion[2,1]
  
  metrics[index,1] = sum(TP+TN)/sum(TP + FP + TN + FN) # acc
  metrics[index,2] = sum(TP)/(sum(TP + FP)) # prec
  metrics[index,3] = sum(TP)/(sum(TP + FN)) # sens
  metrics[index,4] = sum(TN)/(sum(TN) + sum(FP)) # spec
  metrics[index,5] = 2 * metrics[index,2] * metrics[index,3] / (metrics[index,2] + metrics[index,3]) # f1
}

# This produces 'ASA-EM, BIC' row of Table 5.
# Values are Acc, Prec, Sens, Spec, and F1 respectively
round(apply(metrics[1:30,], 2, mean),2)
round(apply(metrics[1:30,], 2, sd),2)