# This file reproduces simulation study results for posterior inference of
# the proposed model, Tables S3 (all model parameters), S4 (NB regression
# coefficients), and S5 (transition probability regression coefficients).


# Simulation --------------------------------------------------------------

source('SourceFunctions.R')
source('NBMCMC.R')
library(gtools)
library(abind)
library(BayesLogit)
library(MASS)
library(coda)
library(knitr)
library(ZIM)
library(mvtnorm)
library(doSNOW)
library(caret)
library(Rcpp)
sourceCpp('FB.cpp')

c1 <- makeCluster(17)
registerDoSNOW(c1)

# Main params
K = 3
N = 100
p = 7

# ZINB Parameters
phi = c(3, 8, 15)

# Hyperparameters
qvec = c(1,1,1)
a = 1
b = 1
c = 1
d = 1
e = 0.01
f = 0.01
g_beta = 1
h_beta = 5
g_rho = 1
h_rho = 5

sims = 50

# Simulate data
X = list()
Y = list()
true_xi = list()

run.mc.sim <- function(A, num.iters = 50) {
  
  # number of possible states
  num.states <- nrow(A)
  
  # stores the states X_t through time
  states <- numeric(num.iters)
  
  # initialize variable for first state 
  states[1] <- sample(1:3, 1, prob = c(0.9, 0.08, 0.02))
  
  for(t in 2:num.iters) {
    
    # probability vector to simulate next state X_{t+1}
    p  <- A[states[t-1], ,t-1]
    
    ## draw from multinomial and determine state
    states[t] <-  which(rmultinom(1, 1, p) == 1)
  }
  return(states)
}

seed_store = 1:sims
myresults <- foreach(current_sim = 1:sims, .packages = c('abind', 'ZIM','mvtnorm','msm','MASS','coda','BayesLogit','gtools','caret', 'Rcpp'), 
                     .combine = 'rbind', .multicombine = TRUE, .verbose = TRUE, .noexport = "FB_ADS") %dopar% { 
                       sourceCpp('FB.cpp')
                       set.seed(seed_store[current_sim])
                       
                       Ti = sample(100:110, 100, replace = T)
                       for (i in 1:N){
                         sex = rep(sample(0:1, 1), Ti[i])
                         age = rep(0, Ti[i])
                         motor = rep(0, Ti[i])
                         compliance = rep(0, Ti[i])
                         compliance_prob = runif(1, min = 0.2, max = 0.8)
                         duration = rep(0, Ti[i])
                         trigger = rep(0, Ti[i])
                         menstrual = rep(0, Ti[i])
                         
                         for (t in 1:Ti[i]){
                           if (t == 1){
                             age[1] = sample(30:23725, 1) /(365 * 65)
                           } else{
                             age[t] = age[t-1] + 1/(365 * 65)
                           }
                           
                           motor[t] = sample(0:5, 1)
                           compliance[t] = rbinom(1,1,prob = c(1-compliance_prob, compliance_prob))
                           
                           if (runif(1) > 0.5){
                             duration[t] = sample(2:3600, 1) /3600
                             trigger_prob = runif(1, min = 0.2, max = 0.8)
                             trigger[t] = rbinom(1,1,prob = c(1-trigger_prob, trigger_prob))
                           }
                         }
                         
                         if (sex[1] == 1){
                           start = sample(1:30,1)
                           if (start < Ti[i]){
                             dur = sample(4:6,1)
                             menstrual[start] = 1
                             while(dur > 0){
                               menstrual[start + dur] = 1
                               dur = dur - 1
                             }
                           }
                           
                           while(start + 37 < Ti[i]){
                             start = start + 30
                             menstrual[start] = 1
                             dur = sample(4:6,1)
                             while(dur > 0){
                               menstrual[start + dur] = 1
                               dur = dur - 1
                             }
                           }
                         }
                         
                         cov = cbind(sex, age, motor, compliance, duration, trigger, menstrual + rnorm(Ti[i], 1, 1))
                         X[[i]] = matrix(cov, Ti[i], 7)
                       }
                       
                       p <- ncol(X[[1]])
                       beta = array(0, c(K, K, p))
                       
                       beta[1,1,c(1,2,3,4,5,6,7)] = 3.5
                       beta[1,2,c(1,2,3)] = 2.9
                       beta[2,1,c(2,3,7)] = 2.4
                       beta[2,2,c(3,7)] = 3.0
                       beta[3,1,c(4,7)] = -2.9
                       beta[3,2,c(4,7)] = -2.5
                       
                       beta_reg = rbind(c(-0.7,-0.8,-0.8,0,-0.8,-0.7,-0.7),
                                        c(-0.4,0,0,-0.4,0,-0.7,-0.6),
                                        c(0,-0.5,0,-0.5,0.5,0.4,0))
                       
                       tempx = c()
                       for(i in 1:N){
                         # Transition Matrix
                         A = array(NA, c(K, K, Ti[i]-1))     # (because for Ti[i] time points, there are (Ti[i]-1) transitions)
                         for (kprime in 1:K){
                           
                           # Transition probabilities for k=1,...(K-1)
                           for (k in (1:K)[-K]){
                             tmp = rep(0, Ti[i]-1)
                             for (ell in 1:K){
                               tmp = tmp + exp(X[[i]][1:(Ti[i]-1),] %*% beta[kprime,ell,])
                             }
                             A[kprime,k,] = exp(X[[i]][1:(Ti[i]-1),] %*% beta[kprime,k,]) / tmp
                           }
                           
                           # Transition probability for k=K
                           A[kprime,K,] = 1 / tmp
                         }
                         
                         true_xi[[i]] = run.mc.sim(A, num.iters = Ti[i])
                         Y[[i]] = rep(0, Ti[i])
                         
                         for(t in 1:Ti[i]){
                           pi = exp(X[[i]][t,]%*%beta_reg[true_xi[[i]][t],])/(1+exp(X[[i]][t,]%*%beta_reg[true_xi[[i]][t],]))
                           
                           mu = phi[true_xi[[i]][t]] * pi / (1-pi)
                           Y[[i]][t] = ZIM::rzinb(n = 1, k = phi[true_xi[[i]][t]], lambda = mu, omega = c(0.7, 0.05, 0.01)[true_xi[[i]][t]])
                           tempx = rbind(tempx, (c(true_xi[[i]][t], pi)))
                         }
                       }
                       
                       Trange = c(1, 6)
                       
                       p1 = mean(tempx[which(tempx[,1] == 1),2])
                       p2 = mean(tempx[which(tempx[,1] == 2),2])
                       p3 = mean(tempx[which(tempx[,1] == 3),2])
                       true_psi1_store = p1
                       true_psi2_store = p2
                       true_psi3_store = p3
                       true_mean1_store = p1*phi[1]/(1-p1)
                       true_mean2_store = p2*phi[2]/(1-p2)
                       true_mean3_store = p3*phi[3]/(1-p3)
                       
                       tryCatch({
                         start_time = Sys.time()
                         results = NB_EPI_MCMC(X = X, Y = Y, maxiter = 20000, K = K, Trange = Trange,
                                               c = c, d = d, e = e, f = f, burnin = 10000,
                                               g_beta = g_beta, h_beta = h_beta, g_rho = g_rho, h_rho = h_rho, 
                                               qvec = qvec)
                         end_time = Sys.time()
                         cat('NB MCMC time: ', end_time - start_time, '\n')
                         
                         time_store = end_time - start_time
                         post_phi = results[[1]]
                         phi_m = rowMeans(post_phi[,10000:20000])
                         q1 = quantile(post_phi[1,10000:20000], probs = c(.025, .975))
                         q2 = quantile(post_phi[2,10000:20000], probs = c(.025, .975))
                         q3 = quantile(post_phi[3,10000:20000], probs = c(.025, .975))
                         phi_ci = rbind(q1, q2, q3)
                         
                         post_p_aux = results[[3]]
                         p_aux_m = rowMeans(post_p_aux[,10000:20000])
                         q1 = quantile(post_p_aux[1,10000:20000], probs = c(.025, .975))
                         q2 = quantile(post_p_aux[2,10000:20000], probs = c(.025, .975))
                         q3 = quantile(post_p_aux[3,10000:20000], probs = c(.025, .975))
                         p_aux_ci = rbind(q1, q2, q3)
                         
                         post_xi = results[[4]]
                         post_pi = results[[5]]
                         pi_m = rowMeans(post_pi[,10000:20000])
                         q1 = quantile(post_pi[1,10000:20000], probs = c(.025, .975))
                         q2 = quantile(post_pi[2,10000:20000], probs = c(.025, .975))
                         q3 = quantile(post_pi[3,10000:20000], probs = c(.025, .975))
                         pi_ci = rbind(q1, q2, q3)
                         
                         betas = results[[8]]
                         betas_m = matrix(0, K, p)
                         betas_ci_l = matrix(0, K, p)
                         betas_ci_u = matrix(0, K, p)
                         
                         templist = matrix(NA, 10000)
                         for(k in 1:K){
                           for(cp in 1:p){
                             templist = matrix(NA, 10000)
                             for(i in 10000:19999){
                               templist[i-9999] = betas[[i+1]][k,cp]    
                             }
                             templist = c(templist[which(templist != 0)],0)
                             betas_m[k,cp] = mean(templist)
                             betas_ci_l[k,cp] = quantile(templist, probs = c(.025))
                             betas_ci_u[k,cp] = quantile(templist, probs = c(.975))
                           }
                         }
                         
                         switch = results[[7]]
                         switch_store = switch
                         
                         psi_switch = results[[11]]
                         psi_switch_store = psi_switch
                         
                         phi_switch = results[[10]]
                         phi_switch_store = phi_switch
                         
                         post_psi = results[[9]]
                         post_psi[,1] = 0.5
                         post_lambda = results[[12]]
                         
                         psi_m = rowMeans(post_psi[,10000:20000])
                         q1 = quantile(post_psi[1,10000:20000], probs = c(.025, .975))
                         q2 = quantile(post_psi[2,10000:20000], probs = c(.025, .975))
                         q3 = quantile(post_psi[3,10000:20000], probs = c(.025, .975))
                         psi_ci = rbind(q1, q2, q3)
                         
                         lambda_m = rowMeans(post_lambda[,10000:20000])
                         q1 = quantile(post_lambda[1,10000:20000], probs = c(.025, .975))
                         q2 = quantile(post_lambda[2,10000:20000], probs = c(.025, .975))
                         q3 = quantile(post_lambda[3,10000:20000], probs = c(.025, .975))
                         lambda_ci = rbind(q1, q2, q3)
                         
                         post_mode_xi = list()
                         for(i in 1:N){
                           post_mode_xi[[i]] = rep(NA, Ti[i])
                           post_mode_xi[[i]] = apply(post_xi[[i]], 2, which.max)
                         }
                         
                         acc_store = sum(unlist(post_mode_xi) == unlist(true_xi))/length(unlist(true_xi))
                         confusion_store = as.matrix(confusionMatrix(as.factor(unlist(post_mode_xi)), as.factor(unlist(true_xi))))
                         err_store = results[[13]]
                         
                         post_gamma_2 = results[[15]]
                         ppi2 = array(0, c(K,K-1,p))
                         for(i in 10000:19999){
                           ppi2 = ppi2 + post_gamma_2[[i]]  
                         }
                         ppi2 = ppi2/10000
                         ads_accept_2 = results[[17]]
                         
                         post_gamma_1 = results[[14]]
                         ppi1 = matrix(0, K, p)
                         for(i in 10000:19999){
                           ppi1 = ppi1 + post_gamma_1[[i]]  
                         }
                         ppi1 = ppi1/10000
                         ads_accept_1 = results[[16]]
                         
                         post_beta = results[[6]]
                         post_betas_m = array(0, c(K, K-1, p))
                         templist = matrix(NA, 10000)
                         for(k1 in 1:K){
                           for(k2 in 1:(K-1)){
                             for(cp in 1:p){
                               templist = matrix(NA, 10000)
                               for(i in 10000:19999){
                                 templist[i-9999] = post_beta[[i+1]][k1,k2,cp]    
                               }
                               templist = c(templist[which(templist != 0)],0)
                               post_betas_m[k1,k2,cp] = mean(templist)
                             }
                           }
                         }
                         
                         list(true_psi1_store, true_psi2_store, true_psi3_store, 
                              true_mean1_store, true_mean2_store, true_mean3_store,
                              acc_store, time_store, phi_m, p_aux_m, pi_m, betas_m, 
                              switch_store, psi_switch_store, phi_switch_store, 
                              psi_m, lambda_m, err_store, confusion_store,
                              phi_ci, p_aux_ci, pi_ci, betas_ci_l, betas_ci_u,
                              psi_ci, lambda_ci, ppi1, ppi2, ads_accept_1, ads_accept_2,
                              post_betas_m) 
                       }, error = function(e){cat("Error:", conditionMessage(e), "\n"); 0})
                     }

stopCluster(c1)
save.image(file = "Sim_S1_ZINB-NHMM-BVS_data.RData")

# Analyze results ---------------------------------------------------------

load("Sim_S1_ZINB-NHMM-BVS_data.RData")

ind = 1:50
m = length(ind)
p = 7

beta = array(0, c(K, K, p))
beta[1,1,c(1,2,3,4,5,6,7)] = 3.5
beta[1,2,c(1,2,3)] = 2.9
beta[2,1,c(2,3,7)] = 2.4
beta[2,2,c(3,7)] = 3.0
beta[3,1,c(4,7)] = -2.9
beta[3,2,c(4,7)] = -2.5
beta_reg = rbind(c(-0.7,-0.8,-0.8,0,-0.8,-0.7,-0.7),
                 c(-0.4,0,0,-0.4,0,-0.7,-0.6),
                 c(0,-0.5,0,-0.5,0.5,0.4,0))

# MSE
psi1_mse = 1/m * sum((unlist(as.data.frame(myresults[,16][ind])[1,]) - unlist(myresults[,1])[ind])^2)
psi2_mse = 1/m * sum((unlist(as.data.frame(myresults[,16][ind])[2,]) - unlist(myresults[,2])[ind])^2)
psi3_mse = 1/m * sum((unlist(as.data.frame(myresults[,16][ind])[3,]) - unlist(myresults[,3])[ind])^2)
lambda1_mse = 1/m * sum((unlist(as.data.frame(myresults[,17][ind])[1,]) - unlist(myresults[,4])[ind])^2)
lambda2_mse = 1/m * sum((unlist(as.data.frame(myresults[,17][ind])[2,]) - unlist(myresults[,5])[ind])^2)
lambda3_mse = 1/m * sum((unlist(as.data.frame(myresults[,17][ind])[3,]) - unlist(myresults[,6])[ind])^2)
r1_mse = 1/m * sum((unlist(as.data.frame(myresults[,9][ind])[1,]) - phi[1])^2)
r2_mse = 1/m * sum((unlist(as.data.frame(myresults[,9][ind])[2,]) - phi[2])^2)
r3_mse = 1/m * sum((unlist(as.data.frame(myresults[,9][ind])[3,]) - phi[3])^2)
zip1_mse = 1/m * sum((unlist(as.data.frame(myresults[,10][ind])[1,]) - 0.7)^2)
zip2_mse = 1/m * sum((unlist(as.data.frame(myresults[,10][ind])[3,]) - 0.05)^2)
zip3_mse = 1/m * sum((unlist(as.data.frame(myresults[,10][ind])[3,]) - 0.01)^2)
pi1_mse = 1/m * sum((unlist(as.data.frame(myresults[,11][ind])[1,]) - 0.9)^2)
pi2_mse = 1/m * sum((unlist(as.data.frame(myresults[,11][ind])[2,]) - 0.08)^2)
pi3_mse = 1/m * sum((unlist(as.data.frame(myresults[,11][ind])[3,]) - 0.02)^2)

# Model parameter performance (Table S3)
tab = data.frame("True parameter" = round(c(0, mean(unlist(myresults[,1])[ind]), mean(unlist(myresults[,2])[ind]), mean(unlist(myresults[,3])[ind]),
                                            mean(unlist(myresults[,4])[ind]), mean(unlist(myresults[,5])[ind]), mean(unlist(myresults[,6])[ind]),
                                            3, 8, 15, 0.7, 0.05, 0.01, 0.9, 0.08, 0.02, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),3),
                 "Post means" = round(c(mean(unlist(myresults[,7])[ind]), mean(unlist(as.data.frame(myresults[,16][ind])[1,])),
                                      mean(unlist(as.data.frame(myresults[,16][ind])[2,])),
                                      mean(unlist(as.data.frame(myresults[,16][ind])[3,])),
                                      mean(unlist(as.data.frame(myresults[,17][ind])[1,])),
                                      mean(unlist(as.data.frame(myresults[,17][ind])[2,])),
                                      mean(unlist(as.data.frame(myresults[,17][ind])[3,])),
                                      mean(unlist(as.data.frame(myresults[,9][ind])[1,])),
                                      mean(unlist(as.data.frame(myresults[,9][ind])[2,])),
                                      mean(unlist(as.data.frame(myresults[,9][ind])[3,])),
                                      mean(unlist(as.data.frame(myresults[,10][ind])[1,])),
                                      mean(unlist(as.data.frame(myresults[,10][ind])[2,])),
                                      mean(unlist(as.data.frame(myresults[,10][ind])[3,])),
                                      mean(unlist(as.data.frame(myresults[,11][ind])[1,])),
                                      mean(unlist(as.data.frame(myresults[,11][ind])[2,])),
                                      mean(unlist(as.data.frame(myresults[,11][ind])[3,])),
                                      mean(unlist(myresults[,13][ind])),
                                      mean(unlist(myresults[,14][ind])),
                                      mean(unlist(myresults[,15][ind])),
                                      mean(unlist(myresults[,8][ind])),
                                      mean(unlist(myresults[,18][ind])),
                                      mean(unlist(as.data.frame(myresults[,29][ind])[1,])),
                                      mean(unlist(as.data.frame(myresults[,29][ind])[2,])),
                                      mean(unlist(as.data.frame(myresults[,29][ind])[3,])),
                                      mean(unlist(as.data.frame(myresults[,30][ind])[1,])),
                                      mean(unlist(as.data.frame(myresults[,30][ind])[2,])),
                                      mean(unlist(as.data.frame(myresults[,30][ind])[3,]))),3),
                 "Standard error" = round(c(sd(unlist(myresults[,7])[ind]), sd(unlist(as.data.frame(myresults[,16][ind])[1,])),
                                            sd(unlist(as.data.frame(myresults[,16][ind])[2,])),
                                            sd(unlist(as.data.frame(myresults[,16][ind])[3,])),
                                            sd(unlist(as.data.frame(myresults[,17][ind])[1,])),
                                            sd(unlist(as.data.frame(myresults[,17][ind])[2,])),
                                            sd(unlist(as.data.frame(myresults[,17][ind])[3,])),
                                            sd(unlist(as.data.frame(myresults[,9][ind])[1,])),
                                            sd(unlist(as.data.frame(myresults[,9][ind])[2,])),
                                            sd(unlist(as.data.frame(myresults[,9][ind])[3,])),
                                            sd(unlist(as.data.frame(myresults[,10][ind])[1,])),
                                            sd(unlist(as.data.frame(myresults[,10][ind])[2,])),
                                            sd(unlist(as.data.frame(myresults[,10][ind])[3,])),
                                            sd(unlist(as.data.frame(myresults[,11][ind])[1,])),
                                            sd(unlist(as.data.frame(myresults[,11][ind])[2,])),
                                            sd(unlist(as.data.frame(myresults[,11][ind])[3,])),
                                            sd(unlist(myresults[,13][ind])),
                                            sd(unlist(myresults[,14][ind])),
                                            sd(unlist(myresults[,15][ind])),
                                            sd(unlist(myresults[,8][ind])),
                                            sd(unlist(myresults[,18][ind])),
                                            sd(unlist(as.data.frame(myresults[,29][ind])[1,])),
                                            sd(unlist(as.data.frame(myresults[,29][ind])[2,])),
                                            sd(unlist(as.data.frame(myresults[,29][ind])[3,])),
                                            sd(unlist(as.data.frame(myresults[,30][ind])[1,])),
                                            sd(unlist(as.data.frame(myresults[,30][ind])[2,])),
                                            sd(unlist(as.data.frame(myresults[,30][ind])[3,]))),3),
                 "Median" = round(c(median(unlist(myresults[,7])[ind]), median(unlist(as.data.frame(myresults[,16][ind])[1,])),
                                    median(unlist(as.data.frame(myresults[,16][ind])[2,])),
                                    median(unlist(as.data.frame(myresults[,16][ind])[3,])),
                                    median(unlist(as.data.frame(myresults[,17][ind])[1,])),
                                    median(unlist(as.data.frame(myresults[,17][ind])[2,])),
                                    median(unlist(as.data.frame(myresults[,17][ind])[3,])),
                                    median(unlist(as.data.frame(myresults[,9][ind])[1,])),
                                    median(unlist(as.data.frame(myresults[,9][ind])[2,])),
                                    median(unlist(as.data.frame(myresults[,9][ind])[3,])),
                                    median(unlist(as.data.frame(myresults[,10][ind])[1,])),
                                    median(unlist(as.data.frame(myresults[,10][ind])[2,])),
                                    median(unlist(as.data.frame(myresults[,10][ind])[3,])),
                                    median(unlist(as.data.frame(myresults[,11][ind])[1,])),
                                    median(unlist(as.data.frame(myresults[,11][ind])[2,])),
                                    median(unlist(as.data.frame(myresults[,11][ind])[3,])),
                                    median(unlist(myresults[,13][ind])),
                                    median(unlist(myresults[,14][ind])),
                                    median(unlist(myresults[,15][ind])),
                                    median(unlist(myresults[,8][ind])),
                                    median(unlist(myresults[,18][ind])),
                                    median(unlist(as.data.frame(myresults[,29][ind])[1,])),
                                    median(unlist(as.data.frame(myresults[,29][ind])[2,])),
                                    median(unlist(as.data.frame(myresults[,29][ind])[3,])),
                                    median(unlist(as.data.frame(myresults[,30][ind])[1,])),
                                    median(unlist(as.data.frame(myresults[,30][ind])[2,])),
                                    median(unlist(as.data.frame(myresults[,30][ind])[3,]))),3),
                 "RMSE" = round(c(0, sqrt(psi1_mse), sqrt(psi2_mse), sqrt(psi3_mse), sqrt(lambda1_mse), sqrt(lambda2_mse), sqrt(lambda3_mse),
                                  sqrt(r1_mse), sqrt(r2_mse), sqrt(r3_mse), sqrt(zip1_mse), sqrt(zip2_mse), sqrt(zip3_mse),
                                  sqrt(pi1_mse), sqrt(pi2_mse), sqrt(pi3_mse), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),3))
kable(tab, format = "latex", booktabs = T)

# Credible intervals
phi_mat = matrix(0, 3, 2)
for(i in ind){
  phi_mat = phi_mat + matrix(myresults[i,20])[1,1][[1]]
}
phi_mat = phi_mat/m

p_mat = matrix(0, 3, 2)
for(i in ind){
  p_mat = p_mat + matrix(myresults[i,21])[1,1][[1]]
}
p_mat = p_mat/m

pi_mat = matrix(0, 3, 2)
for(i in ind){
  pi_mat = pi_mat + matrix(myresults[i,22])[1,1][[1]]
}
pi_mat = pi_mat/m

psi_mat = matrix(0, 3, 2)
for(i in ind){
  psi_mat = psi_mat + matrix(myresults[i,25])[1,1][[1]]
}
psi_mat = psi_mat/m

mean_mat = matrix(0, 3, 2)
for(i in ind){
  mean_mat = mean_mat + matrix(myresults[i,26])[1,1][[1]]
}
mean_mat = mean_mat/m

betal_mat = matrix(0, 3, p)
for(i in ind){
  betal_mat = betal_mat + matrix(myresults[i,23])[1,1][[1]]
}
betal_mat = betal_mat/m

betau_mat = matrix(0, 3, p)
for(i in ind){
  betau_mat = betau_mat + matrix(myresults[i,24])[1,1][[1]]
}
betau_mat = betau_mat/m

totalmat = matrix(0, 3, 3)
for(i in ind){
  totalmat = totalmat + matrix(myresults[i,19])[1,1][[1]]
}

# Latent states
metrics = matrix(NA, nrow = m, ncol = 10)
TP = rep(NA, 3)
FP = rep(NA, 3)
TN = rep(NA, 3)
FN = rep(NA, 3)
for(index in 1:length(ind)){
  myi = ind[index]
  current_confusion = unname(myresults[myi,19])[[1]]
  for(k in 1:3){
    TP[k] = current_confusion[k,k]
    FP[k] = sum(current_confusion[k,-k])
    TN[k] = sum(current_confusion[-k,-k])
    FN[k] = sum(current_confusion[-k,k])
  }
  metrics[index,1] = sum(TP+TN)/sum(TP + FP + TN + FN) #acc
  metrics[index,2] = sum(TP)/(sum(TP) + sum(FP)) #prec
  metrics[index,3] = sum(TP)/(sum(TP) + sum(FN)) #sens
  metrics[index,4] = sum(TN)/(sum(TN) + sum(FP)) #spec
  metrics[index,5] = 2 * metrics[index,2] * metrics[index,3] / (metrics[index,2] + metrics[index,3])
  metrics[index,6] = mean((TP+TN)/(TP + FP + TN + FN)) # acc
  metrics[index,7] = mean(TP/(TP + FP)) #prec
  metrics[index,8] = mean(TP/(TP + FN)) #sens
  metrics[index,9] = mean(TN/(TN + FP)) #spec
  metrics[index,10] = 2 * metrics[index,7] * metrics[index,8] / (metrics[index,7] + metrics[index,8])
}

round(colMeans(metrics),2)
round(apply(metrics, 2, sd),2)

# Emissions (Table S4)
ppitotal = matrix(0, 3, p)
for(i in ind){
  ppitotal = ppitotal + matrix(myresults[i,27])[1,1][[1]]
}
ppitotal = ppitotal/m

par(mfrow=c(3,1), mar = c(3,5,3,3))
truth = (beta_reg != 0)
plot(1:p, ppitotal[1,], ylim = c(0,1), type = "h", xlab = '', ylab = 'PPI', main = 'State 1')
points(1:p, truth[1,], col = 'red', pch = 19)
abline(h = 0.5, col = 'red')
plot(1:p, ppitotal[2,], ylim = c(0,1), type = "h", xlab = '', ylab = 'PPI', main = 'State 2')
points(1:p, truth[2,], col = 'red', pch = 19)
abline(h = 0.5, col = 'red')
plot(1:p, ppitotal[3,], ylim = c(0,1), type = "h", xlab = '', ylab = '', main = 'State 3')
points(1:p, truth[3,], col = 'red', pch = 19)
abline(h = 0.5, col = 'red')

beta_post_means = matrix(0, K, p)
beta_post_sds = matrix(0, K, p)
beta_post_medians = matrix(0, K, p)
beta_post_mse = matrix(0, K, p)
templist = c()

for(k in 1:K){
  for(cp in 1:p){
    templist = c()
    for(index in ind){
      templist = c(templist, myresults[,12][[index]][k,cp])
    }
    beta_post_means[k,cp] = mean(templist)
    beta_post_sds[k,cp] = sd(templist)
    beta_post_medians[k,cp] = median(templist)
    beta_post_mse[k,cp] = 1/m * sum((templist - beta_reg[k,cp])^2)
  }
}

tab1 = data.frame("True beta1" = beta_reg[1,],
                  "Posterior mean of beta1" = round(beta_post_means[1,],3),
                  "SD" = round(beta_post_sds[1,],3),
                  "PPI" = round(ppitotal[1,],3),
                  "CI_l" = round(betal_mat[1,],3),
                  "CI_u" = round(betau_mat[1,],3),
                  "Median" = round(beta_post_medians[1,],3),
                  "RMSE" = round(sqrt(beta_post_mse[1,]),3))
tab2 = data.frame("True beta2" = beta_reg[2,],
                  "Posterior mean of beta2" = round(beta_post_means[2,],3),
                  "SD" = round(beta_post_sds[2,],3),
                  "PPI" = round(ppitotal[2,],3),
                  "CI_l" = round(betal_mat[2,],3),
                  "CI_u" = round(betau_mat[2,],3),
                  "Median" = round(beta_post_medians[2,],3),
                  "RMSE" = round(sqrt(beta_post_mse[2,]),3))
tab3 = data.frame("True beta3" = beta_reg[3,],
                  "Posterior mean of beta3" = round(beta_post_means[3,],3),
                  "SD" = round(beta_post_sds[3,],3),
                  "PPI" = round(ppitotal[3,],3),
                  "CI_l" = round(betal_mat[3,],3),
                  "CI_u" = round(betau_mat[3,],3),
                  "Median" = round(beta_post_medians[3,],3),
                  "RMSE" = round(sqrt(beta_post_mse[3,]),3))

kable(tab1, format = "latex", booktabs = T)
kable(tab2, format = "latex", booktabs = T)
kable(tab3, format = "latex", booktabs = T)

# Transition probability regression coefficients (Table S5)
mat = matrix(NA, nrow = 42, ncol = 7)
count = 1
ind = 1:50
for(k1 in 1:K){
  for(k2 in 1:2){
    for(cp in 1:p){
      templist = c()
      for(sim in 1:50){
        templist = c(templist, (unname(myresults[sim, 31])[[1]])[k1,k2,cp])
      }
      rmse = 1/length(templist) * sum((templist - beta[k1,k2,cp])^2)
      mat[count,] = c(k1,k2,cp,beta[k1,k2,cp],mean(templist), sd(templist), rmse)
      count = count + 1
    }
  }
}
colnames(mat) = c('Original state', 'New state', 'Covariate #', 'True val', 'Post mean', 'SD', 'RMSE')
mat
