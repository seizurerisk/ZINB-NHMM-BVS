# This file reproduces simulation study results for the sensitivity analysis
# in Tables 1 and 2: Different sets of hyperparameters were investigated for
# effect on model performance, in terms of classification of covariate
# selection and latent states.


# Simulation --------------------------------------------------------------

source('SourceFunctions_sensitivity.R')
source('NBMCMC_sensitivity.R')
library(gtools)
library(abind)
library(BayesLogit)
library(MASS)
library(coda)
library(knitr)
library(ZIM)
library(mvtnorm)
library(doSNOW)
library(caret)
library(Rcpp)
sourceCpp('FB.cpp')

c1 <- makeCluster(24)
registerDoSNOW(c1)

# Main params
K = 3
N = 100
p = 7

# ZINB Parameters
phi = c(3, 8, 15)

# Simulate data
sims = 260
X = list()
Y = list()
true_xi = list()

run.mc.sim <- function(A, num.iters = 50) {
  
  # number of possible states
  num.states <- nrow(A)
  
  # stores the states X_t through time
  states <- numeric(num.iters)
  
  # initialize variable for first state 
  states[1] <- sample(1:3, 1, prob = c(0.9, 0.08, 0.02))
  
  for(t in 2:num.iters) {
    
    # probability vector to simulate next state X_{t+1}
    p  <- A[states[t-1], ,t-1]
    
    ## draw from multinomial and determine state
    states[t] <-  which(rmultinom(1, 1, p) == 1)
  }
  return(states)
}

seed_store = rep(1:20, times = 13)
myresults <- foreach(current_sim = 1:sims, .packages = c('abind', 'ZIM','mvtnorm','msm','MASS','coda','BayesLogit','gtools','caret', 'Rcpp'), 
                     .combine = 'rbind', .multicombine = TRUE, .verbose = TRUE, .noexport = "FB_ADS") %dopar% { 
                       sourceCpp('FB.cpp')
                       set.seed(seed_store[current_sim])
                       
                       Ti = sample(100:110, 100, replace = T)
                       for (i in 1:N){
                         sex = rep(sample(0:1, 1), Ti[i])
                         age = rep(0, Ti[i])
                         motor = rep(0, Ti[i])
                         compliance = rep(0, Ti[i])
                         compliance_prob = runif(1, min = 0.2, max = 0.8)
                         duration = rep(0, Ti[i])
                         trigger = rep(0, Ti[i])
                         menstrual = rep(0, Ti[i])
                         
                         for (t in 1:Ti[i]){
                           if (t == 1){
                             age[1] = sample(30:23725, 1) /(365 * 65)
                           } else{
                             age[t] = age[t-1] + 1/(365 * 65)
                           }
                           
                           motor[t] = sample(0:5, 1)
                           compliance[t] = rbinom(1,1,prob = c(1-compliance_prob, compliance_prob))
                           
                           if (runif(1) > 0.5){
                             duration[t] = sample(2:3600, 1) /3600
                             trigger_prob = runif(1, min = 0.2, max = 0.8)
                             trigger[t] = rbinom(1,1,prob = c(1-trigger_prob, trigger_prob))
                           }
                         }
                         
                         if (sex[1] == 1){
                           start = sample(1:30,1)
                           if (start < Ti[i]){
                             dur = sample(4:6,1)
                             menstrual[start] = 1
                             while(dur > 0){
                               menstrual[start + dur] = 1
                               dur = dur - 1
                             }
                           }
                           
                           while(start + 37 < Ti[i]){
                             start = start + 30
                             menstrual[start] = 1
                             dur = sample(4:6,1)
                             while(dur > 0){
                               menstrual[start + dur] = 1
                               dur = dur - 1
                             }
                           }
                         }
                         
                         cov = cbind(sex, age, motor, compliance, duration, trigger, menstrual + rnorm(Ti[i], 1, 1))
                         X[[i]] = matrix(cov, Ti[i], 7)
                       }
                       
                       p <- ncol(X[[1]])
                       beta = array(0, c(K, K, p))
                       
                       beta[1,1,c(1,2,3,4,5,6,7)] = 3.5
                       beta[1,2,c(1,2,3)] = 2.9
                       beta[2,1,c(2,3,7)] = 2.4
                       beta[2,2,c(3,7)] = 3.0
                       beta[3,1,c(4,7)] = -2.9
                       beta[3,2,c(4,7)] = -2.5
                       
                       beta_reg = rbind(c(-0.7,-0.8,-0.8,0,-0.8,-0.7,-0.7),
                                        c(-0.4,0,0,-0.4,0,-0.7,-0.6),
                                        c(0,-0.5,0,-0.5,0.5,0.4,0))
                       
                       tempx = c()
                       for(i in 1:N){
                         # Transition Matrix
                         A = array(NA, c(K, K, Ti[i]-1))     # (because for Ti[i] time points, there are (Ti[i]-1) transitions)
                         for (kprime in 1:K){
                           
                           # Transition probabilities for k=1,...(K-1)
                           for (k in (1:K)[-K]){
                             tmp = rep(0, Ti[i]-1)
                             for (ell in 1:K){
                               tmp = tmp + exp(X[[i]][1:(Ti[i]-1),] %*% beta[kprime,ell,])
                             }
                             A[kprime,k,] = exp(X[[i]][1:(Ti[i]-1),] %*% beta[kprime,k,]) / tmp
                           }
                           
                           # Transition probability for k=K
                           A[kprime,K,] = 1 / tmp
                         }
                         
                         true_xi[[i]] = run.mc.sim(A, num.iters = Ti[i])
                         Y[[i]] = rep(0, Ti[i])
                         
                         for(t in 1:Ti[i]){
                           pi = exp(X[[i]][t,]%*%beta_reg[true_xi[[i]][t],])/(1+exp(X[[i]][t,]%*%beta_reg[true_xi[[i]][t],]))
                           
                           mu = phi[true_xi[[i]][t]] * pi / (1-pi)
                           Y[[i]][t] = ZIM::rzinb(n = 1, k = phi[true_xi[[i]][t]], lambda = mu, omega = c(0.7, 0.05, 0.01)[true_xi[[i]][t]])
                           tempx = rbind(tempx, (c(true_xi[[i]][t], pi)))
                         }
                       }
                       
                       Trange = c(1, 6)
                       
                       p1 = mean(tempx[which(tempx[,1] == 1),2])
                       p2 = mean(tempx[which(tempx[,1] == 2),2])
                       p3 = mean(tempx[which(tempx[,1] == 3),2])
                       true_psi1_store = p1
                       true_psi2_store = p2
                       true_psi3_store = p3
                       true_mean1_store = p1*phi[1]/(1-p1)
                       true_mean2_store = p2*phi[2]/(1-p2)
                       true_mean3_store = p3*phi[3]/(1-p3)
                       
                       # Hyperparameters
                       if(current_sim %in% 21:40){
                         sigma_beta = 10
                       } else if(current_sim %in% 41:60){
                         sigma_beta = 0.1
                       } else if(current_sim %in% 61:80){
                         sigma_beta = 0.01
                       } else{
                         sigma_beta = 1
                       }
                       
                       if(current_sim %in% 81:100){
                         g_beta = 1; h_beta = 1
                       } else if(current_sim %in% 101:120){
                         g_beta = 1; h_beta = 2
                       } else if(current_sim %in% 121:140){
                         g_beta = 1; h_beta = 20
                       } else{
                         g_beta = 1; h_beta = 5
                       }

                       if(current_sim %in% 141:160){
                         sigma_rho = 10
                       } else if(current_sim %in% 161:180){
                         sigma_rho = 0.1
                       } else if(current_sim %in% 181:200){
                         sigma_rho = 0.01
                       } else{
                         sigma_rho = 1
                       }
                       
                       if(current_sim %in% 201:220){
                         g_rho = 1; h_rho = 1
                       } else if(current_sim %in% 221:240){
                         g_rho = 1; h_rho = 2
                       } else if(current_sim %in% 241:260){
                         g_rho = 1; h_rho = 20
                       } else{
                         g_rho = 1; h_rho = 5
                       }
                       c = 1
                       d = 1
                       e = 0.01
                       f = 0.01
                       qvec = c(1,1,1)

                       tryCatch({
                         start_time = Sys.time()
                         burnin = 10000
                         maxiter = 20000
                         results = NB_EPI_MCMC(X = X, Y = Y, maxiter = maxiter, K = K, Trange = Trange,
                                               c = c, d = d, e = e, f = f, burnin = burnin,
                                               g_beta = g_beta, h_beta = h_beta, g_rho = g_rho, h_rho = h_rho, 
                                               qvec = qvec,
                                               sigma_rho = sigma_rho, sigma_beta = sigma_beta) #, true_xi = true_xi)
                         end_time = Sys.time()
                         cat('NB MCMC time: ', end_time - start_time, '\n')
                         
                         time_store = end_time - start_time
                         
                         post_xi = results[[4]]
                         
                         post_mode_xi = list()
                         for(i in 1:N){
                           post_mode_xi[[i]] = rep(NA, Ti[i])
                           post_mode_xi[[i]] = apply(post_xi[[i]], 2, which.max)
                         }
                         
                         post_gamma_1 = results[[14]]
                         post_gamma_2 = results[[15]]
                         
                         ppi2 = array(0, c(K,K-1,p))
                         for(i in burnin:maxiter){
                           ppi2 = ppi2 + post_gamma_2[[i]]
                         }
                         ppi2 = ppi2/length(burnin:maxiter)

                         ppi1 = matrix(0, K, p)
                         for(i in burnin:maxiter){
                           ppi1 = ppi1 + post_gamma_1[[i]]
                         }
                         ppi1 = ppi1/length(burnin:maxiter)
                         
                         list(time_store, unlist(true_xi), unlist(post_mode_xi),
                              ppi1, ppi2) 
                       }, error = function(e){cat("Error:", conditionMessage(e), "\n"); 0})
                     }

stopCluster(c1)
save.image(file = "Sim_2_sensitivity_data.RData")

# Results -----------------------------------------------------------------

load("Sim_2_sensitivity_data.RData")

metrics = matrix(NA, nrow = sims, ncol = 11)
beta = array(0, c(K, K, p))
beta[1,1,c(1,2,3,4,5,6,7)] = 3.5
beta[1,2,c(1,2,3)] = 2.9
beta[2,1,c(2,3,7)] = 2.4
beta[2,2,c(3,7)] = 3.0
beta[3,1,c(4,7)] = -2.9
beta[3,2,c(4,7)] = -2.5

beta_reg = rbind(c(-0.7,-0.8,-0.8,0,-0.8,-0.7,-0.7),
                 c(-0.4,0,0,-0.4,0,-0.7,-0.6),
                 c(0,-0.5,0,-0.5,0.5,0.4,0))
trueppi1 = (beta_reg != 0)
trueppi2 = (beta[,-3,] != 0)

# Covariate selection
for(i in 1:sims){
  if(i >= 21 & i <= 140){
    ppi2 = (myresults[i,5][[1]] >= 0.5)
    metrics[i,1] = sum(ppi2)
    metrics[i,2] = sum((ppi2 == 0) & (trueppi2 == 1))/(sum((ppi2 == 0) & (trueppi2 == 1)) + sum((ppi2 == 1) & (trueppi2 == 1)))
    metrics[i,3] = sum((ppi2 == 1) & (trueppi2 == 0))/(sum((ppi2 == 1) & (trueppi2 == 0)) + sum((ppi2 == 0) & (trueppi2 == 0)))
    TP = sum((ppi2 == 1) & (trueppi2 == 1))
    FP = sum((ppi2 == 1) & (trueppi2 == 0))
    TN = sum((ppi2 == 0) & (trueppi2 == 0))
    FN = sum((ppi2 == 0) & (trueppi2 == 1))
    metrics[i,4] = TP/(TP+FN)  # sens
    metrics[i,11] = prec = TP/(TP + FP)  # prec
    metrics[i,5] = TN/(TN+FP)  # spec
    metrics[i,6] = 2*prec*metrics[i,4]/(prec+metrics[i,4])  # f1
  } else if (i >= 141 & i <= 260){
    ppi1 = (myresults[i,4][[1]] >= 0.5)
    metrics[i,1] = sum(ppi1)
    metrics[i,2] = sum((ppi1 == 0) & (trueppi1 == 1))/(sum((ppi1 == 0) & (trueppi1 == 1)) + sum((ppi1 == 1) & (trueppi1 == 1)))
    metrics[i,3] = sum((ppi1 == 1) & (trueppi1 == 0))/(sum((ppi1 == 1) & (trueppi1 == 0)) + sum((ppi1 == 0) & (trueppi1 == 0)))
    TP = sum((ppi1 == 1) & (trueppi1 == 1))
    FP = sum((ppi1 == 1) & (trueppi1 == 0))
    TN = sum((ppi1 == 0) & (trueppi1 == 0))
    FN = sum((ppi1 == 0) & (trueppi1 == 1))
    metrics[i,4] = TP/(TP+FN)  # sens
    metrics[i,11] = prec = TP/(TP + FP)  # prec
    metrics[i,5] = TN/(TN+FP)  # spec
    metrics[i,6] = 2*prec*metrics[i,4]/(prec+metrics[i,4])  # f1
  } else if (i >= 1 & i <= 20){
    
    # Comment out below to get emission results for default row
    ppi1 = (myresults[i,4][[1]] >= 0.5)
    metrics[i,1] = sum(ppi1)
    metrics[i,2] = sum((ppi1 == 0) & (trueppi1 == 1))/(sum((ppi1 == 0) & (trueppi1 == 1)) + sum((ppi1 == 1) & (trueppi1 == 1)))
    metrics[i,3] = sum((ppi1 == 1) & (trueppi1 == 0))/(sum((ppi1 == 1) & (trueppi1 == 0)) + sum((ppi1 == 0) & (trueppi1 == 0)))
    TP = sum((ppi1 == 1) & (trueppi1 == 1))
    FP = sum((ppi1 == 1) & (trueppi1 == 0))
    TN = sum((ppi1 == 0) & (trueppi1 == 0))
    FN = sum((ppi1 == 0) & (trueppi1 == 1))
    metrics[i,4] = TP/(TP+FN)  # sens
    metrics[i,11] = prec = TP/(TP + FP)  # prec
    metrics[i,5] = TN/(TN+FP)  # spec
    metrics[i,6] = 2*prec*metrics[i,4]/(prec+metrics[i,4])  # f1
    
    # Comment out below to get transition results for default row
    # ppi2 = (myresults[i,5][[1]] >= 0.5)
    # metrics[i,1] = sum(ppi2)
    # metrics[i,2] = sum((ppi2 == 0) & (trueppi2 == 1))/(sum((ppi2 == 0) & (trueppi2 == 1)) + sum((ppi2 == 1) & (trueppi2 == 1)))
    # metrics[i,3] = sum((ppi2 == 1) & (trueppi2 == 0))/(sum((ppi2 == 1) & (trueppi2 == 0)) + sum((ppi2 == 0) & (trueppi2 == 0)))
    # TP = sum((ppi2 == 1) & (trueppi2 == 1))
    # FP = sum((ppi2 == 1) & (trueppi2 == 0))
    # TN = sum((ppi2 == 0) & (trueppi2 == 0))
    # FN = sum((ppi2 == 0) & (trueppi2 == 1))
    # metrics[i,4] = TP/(TP+FN)  # sens
    # metrics[i,11] = prec = TP/(TP + FP)  # prec
    # metrics[i,5] = TN/(TN+FP)  # spec
    # metrics[i,6] = 2*prec*metrics[i,4]/(prec+metrics[i,4])  # f1
  }
  
  TP = rep(NA, 3)
  FP = rep(NA, 3)
  TN = rep(NA, 3)
  FN = rep(NA, 3)
  current_confusion = as.matrix(confusionMatrix(as.factor(unname(myresults[i,3])[[1]]), as.factor(unname(myresults[i,2])[[1]])))
  for(k in 1:K){
    TP[k] = current_confusion[k,k]
    FP[k] = sum(current_confusion[k,-k])
    TN[k] = sum(current_confusion[-k,-k])
    FN[k] = sum(current_confusion[-k,k])
  }
  
  metrics[i,7] = mean((TP+TN)/(TP + FP + TN + FN)) # acc
  prec = mean(TP/(TP + FP)) # precision
  metrics[i,8] = mean(TP/(TP + FN)) # sens
  metrics[i,9] = 2 * prec * metrics[i,8] / (prec + metrics[i,8]) # f1
  metrics[i,10] = mean(TN/(TN + FP)) # spec
}

# Columns 1-6 are '# Selected', FNR, FPR, Sens, Spec, F1, column 11 is Prec in Table 2
round(apply(metrics[1:20,], 2, mean),2) # default g_rho = 1; h_rho = 5 sigma_rho = 1 g_beta = 1; h_beta = 5 sigma_beta = 1
round(apply(metrics[21:40,], 2, mean),2) # sigma_beta = 1/10
round(apply(metrics[41:60,], 2, mean),2) # sigma_beta = 1/0.1
round(apply(metrics[61:80,], 2, mean),2) # sigma_beta = 1/0.01
round(apply(metrics[81:100,], 2, mean),2) # g_beta = 1; h_beta = 1
round(apply(metrics[101:120,], 2, mean),2) # g_beta = 1; h_beta = 2
round(apply(metrics[121:140,], 2, mean),2) # g_beta = 1; h_beta = 20
round(apply(metrics[141:160,], 2, mean),2) # sigma_rho = 1/10
round(apply(metrics[161:180,], 2, mean),2) # sigma_rho = 1/0.1
round(apply(metrics[181:200,], 2, mean),2) # sigma_rho = 1/0.01
round(apply(metrics[201:220,], 2, mean),2) # g_rho = 1; h_rho = 1
round(apply(metrics[221:240,], 2, mean),2) # g_rho = 1; h_rho = 2
round(apply(metrics[241:260,], 2, mean),2) # g_rho = 1; h_rho = 20


# Latent states
metrics = matrix(NA, nrow = sims, ncol = 10)
for(i in 1:sims){
  TP = rep(NA, 3)
  FP = rep(NA, 3)
  TN = rep(NA, 3)
  FN = rep(NA, 3)
  current_confusion = as.matrix(confusionMatrix(as.factor(unname(myresults[i,3])[[1]]), as.factor(unname(myresults[i,2])[[1]])))
  for(k in 1:K){
    TP[k] = current_confusion[k,k]
    FP[k] = sum(current_confusion[k,-k])
    TN[k] = sum(current_confusion[-k,-k])
    FN[k] = sum(current_confusion[-k,k])
  }
  
  metrics[i,1] = sum(TP+TN)/sum(TP + FP + TN + FN)
  metrics[i,2] = sum(TP)/(sum(TP) + sum(FP)) # prec
  metrics[i,3] = sum(TP)/(sum(TP) + sum(FN)) # sens
  metrics[i,4] = sum(TN)/(sum(TN) + sum(FP)) # spec
  metrics[i,5] = 2 * metrics[i,2] * metrics[i,3] / (metrics[i,2] + metrics[i,3]) # f1
  metrics[i,6] = mean((TP+TN)/(TP + FP + TN + FN))
  metrics[i,7] = mean(TP/(TP + FP)) # prec
  metrics[i,8] = mean(TP/(TP + FN)) # sens
  metrics[i,9] = mean(TN/(TN + FP)) # spec
  metrics[i,10] = 2 * metrics[i,7] * metrics[i,8] / (metrics[i,7] + metrics[i,8])
}

# Columns 6-10 are for Table 1 (Acc, Prec, Sens, Spec, F1)
# Mean
round(apply(metrics[1:20,], 2, mean),2) # default g_rho = 1; h_rho = 5 sigma_rho = 1 g_beta = 1; h_beta = 5 sigma_beta = 1
round(apply(metrics[21:40,], 2, mean),2) # sigma_beta = 1/10
round(apply(metrics[41:60,], 2, mean),2) # sigma_beta = 1/0.1
round(apply(metrics[61:80,], 2, mean),2) # sigma_beta = 1/0.01
round(apply(metrics[81:100,], 2, mean),2) # g_beta = 1; h_beta = 1
round(apply(metrics[101:120,], 2, mean),2) # g_beta = 1; h_beta = 2
round(apply(metrics[121:140,], 2, mean),2) # g_beta = 1; h_beta = 20
round(apply(metrics[141:160,], 2, mean),2) # sigma_rho = 1/10
round(apply(metrics[161:180,], 2, mean),2) # sigma_rho = 1/0.1
round(apply(metrics[181:200,], 2, mean),2) # sigma_rho = 1/0.01
round(apply(metrics[201:220,], 2, mean),2) # g_rho = 1; h_rho = 1
round(apply(metrics[221:240,], 2, mean),2) # g_rho = 1; h_rho = 2
round(apply(metrics[241:260,], 2, mean),2) # g_rho = 1; h_rho = 20

# SD
round(apply(metrics[1:20,], 2, sd),2) # default g_rho = 1; h_rho = 5 sigma_rho = 1 g_beta = 1; h_beta = 5 sigma_beta = 1
round(apply(metrics[21:40,], 2, sd),2) # sigma_beta = 1/10
round(apply(metrics[41:60,], 2, sd),2) # sigma_beta = 1/0.1
round(apply(metrics[61:80,], 2, sd),2) # sigma_beta = 1/0.01
round(apply(metrics[81:100,], 2, sd),2) # g_beta = 1; h_beta = 1
round(apply(metrics[101:120,], 2, sd),2) # g_beta = 1; h_beta = 2
round(apply(metrics[121:140,], 2, sd),2) # g_beta = 1; h_beta = 20
round(apply(metrics[141:160,], 2, sd),2) # sigma_rho = 1/10
round(apply(metrics[161:180,], 2, sd),2) # sigma_rho = 1/0.1
round(apply(metrics[181:200,], 2, sd),2) # sigma_rho = 1/0.01
round(apply(metrics[201:220,], 2, sd),2) # g_rho = 1; h_rho = 1
round(apply(metrics[221:240,], 2, sd),2) # g_rho = 1; h_rho = 2
round(apply(metrics[241:260,], 2, sd),2) # g_rho = 1; h_rho = 20