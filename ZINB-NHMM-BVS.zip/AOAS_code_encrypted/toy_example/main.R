# Import packages/source files --------------------------------------------

library(ZIM)
library(Rcpp)
library(gtools)
library(abind)
library(BayesLogit)
library(mvtnorm)

source('PG_SourceFunctions.R') 
source('NBMCMC.R')
sourceCpp('FB_SourceFunctions.cpp')

# Generate simulated data -------------------------------------------------

set.seed(0)
K = 3       # Number of clusters
N = 100     # Number of patients
p = 7       # Number of covariates

phi = c(3, 8, 15)        # NB dispersions
pi = c(0.8, 0.15, 0.05)   # Probabilities for initial state
zip = c(0.7, 0.05, 0.01) # Zero-inflation parameters
Trange = c(1, 6)         # Limits for initializing latent states

beta = array(0, c(K, K, p))        # Transition probability regression coefficients
beta[1,1,c(1,2,3,4,5,6,7)] = 3.5   # 1->1 transition
beta[1,2,c(1,2,3)] = 2.9           # 1->2
beta[2,1,c(2,3,7)] = 2.4           # 2->1
beta[2,2,c(3,7)] = 3.0             # 2->2
beta[3,1,c(4,7)] = -2.9            # 3->1
beta[3,2,c(4,7)] = -2.5            # 3->2

rho = rbind(c(-0.7, -0.8, -0.8,    0, -0.8, -0.7,  -0.7),  # NB regression coefficients
            c(-0.4,    0,    0, -0.4,    0, -0.7,  -0.6),
            c(   0, -0.5,    0, -0.5,  0.5,  0.4,     0))

X = list()         # Covariates
Y = list()         # Counts 
true_xi = list()   # States
Ti = sample(100:110, N, replace = T)  # Time points per pat, T_i

# Helper function for simulating a NHMM
NHMM_sim <- function(A, maxiter = 50, K = 3) {
  num_states = nrow(A)
  states = numeric(maxiter)
  states[1] = sample(1:K, 1, prob = pi)
  for(t in 2:maxiter){
    p = A[states[t-1], ,t-1]
    states[t] = which(rmultinom(1, 1, p) == 1)
  }
  return(states)
}

# Simulate covariates
for (i in 1:N){
  sex = rep(sample(0:1, 1), Ti[i])
  age = rep(0, Ti[i])
  motor = rep(0, Ti[i])
  compliance = rep(0, Ti[i])
  compliance_prob = runif(1, min = 0.2, max = 0.8)
  duration = rep(0, Ti[i])
  trigger = rep(0, Ti[i])
  menstrual = rep(0, Ti[i])
  
  for (t in 1:Ti[i]){
    if (t == 1){
      age[1] = sample(30:23725, 1) /(365 * 65)
    } else{
      age[t] = age[t-1] + 1/(365 * 65)
    }
    
    motor[t] = sample(0:5, 1)
    compliance[t] = rbinom(1, 1, prob = c(1-compliance_prob, compliance_prob))
    
    if (runif(1) > 0.5){
      duration[t] = sample(2:3600, 1) /3600
      trigger_prob = runif(1, min = 0.2, max = 0.8)
      trigger[t] = rbinom(1, 1, prob = c(1-trigger_prob, trigger_prob))
    }
  }
  
  if (sex[1] == 1){
    start = sample(1:30, 1)
    if (start < Ti[i]){
      dur = sample(4:6, 1)
      menstrual[start] = 1
      while(dur > 0){
        menstrual[start + dur] = 1
        dur = dur - 1
      }
    }
    
    while(start + 37 < Ti[i]){
      start = start + 30
      menstrual[start] = 1
      dur = sample(4:6, 1)
      while(dur > 0){
        menstrual[start + dur] = 1
        dur = dur - 1
      }
    }
  }
  
  cov = cbind(sex, age, motor, compliance, duration, trigger, menstrual + rnorm(Ti[i], 1, 1))
  X[[i]] = matrix(cov, Ti[i], 7)
}

# Simulate emissions
for(i in 1:N){
  # Non-homogeneous transition Matrix
  A = array(NA, c(K, K, Ti[i]-1))
  for (kprime in 1:K){
    for (k in (1:K)[-K]){
      tmp = rep(0, Ti[i]-1)
      for (ell in 1:K){
        tmp = tmp + exp(X[[i]][1:(Ti[i]-1),] %*% beta[kprime,ell,])
      }
      A[kprime,k,] = exp(X[[i]][1:(Ti[i]-1),] %*% beta[kprime,k,]) / tmp
    }
    A[kprime,K,] = 1 / tmp
  }
  
  true_xi[[i]] = NHMM_sim(A, maxiter = Ti[i], K = K)
  Y[[i]] = rep(0, Ti[i])
  
  for(t in 1:Ti[i]){
    psi = exp(X[[i]][t,] %*% rho[true_xi[[i]][t],])/(1 + exp(X[[i]][t,] %*% rho[true_xi[[i]][t],]))
    mu = phi[true_xi[[i]][t]] * psi / (1 - psi)
    Y[[i]][t] = ZIM::rzinb(n = 1, k = phi[true_xi[[i]][t]], lambda = mu, omega = zip[true_xi[[i]][t]])
  }
}
mu = rep(NA, K)
mu[1] = mean(unlist(Y)[which(unlist(true_xi) == 1)])
mu[2] = mean(unlist(Y)[which(unlist(true_xi) == 2)])
mu[3] = mean(unlist(Y)[which(unlist(true_xi) == 3)])

# Run ---------------------------------------------------------------------

# Hyperparameters
g_beta = 1; h_beta = 5  # Beta(g,h) prior for inclusion indicators on TP coefs
g_rho = 1; h_rho = 5    # Beta(g,h) prior for inclusion indicators on NB coefs
c = 1; d = 1            # Beta(c,d) prior on zero inflation parameters
e = 0.01; f = 0.01      # Gamma(e,f) prior on dispersions phi (r in paper)
qvec = rep(1,K)         # Dirichlet prior on probabilities of initial state

# MCMC settings
burnin = 2500
maxiter = 5000

start_time = Sys.time()
results = NBMCMC(X = X, Y = Y, maxiter = maxiter, burnin = burnin, K = K, Trange = Trange,
                 c = c, d = d, e = e, f = f, 
                 g_beta = g_beta, h_beta = h_beta, g_rho = g_rho, h_rho = h_rho, 
                 qvec = qvec)
end_time = Sys.time()
cat('MCMC elapsed time: ', end_time - start_time, '\n')

# Results -----------------------------------------------------------------

post_phi = results[[1]]
post_p_aux = results[[3]]
post_xi = results[[4]]
post_pi = results[[5]]
post_beta = results[[6]]
num_switch = results[[7]]
post_rho = results[[8]]
post_psi = results[[9]]
post_lambda = results[[10]]
errors = results[[11]]
post_gamma_1 = results[[12]]
post_gamma_2 = results[[13]]
ads_accept_1 = results[[14]]
ads_accept_2 = results[[15]]

# Dispersions
par(mfrow = c(K,1), mar = c(4,4,3,1))
for(k in 1:K){
  plot(1:maxiter, post_phi[k,], type = 'l', main = paste('State',k,'dispersion'),
       ylab = bquote(r[.(k)]), xlab = 'Iteration')
  abline(h = phi[k], col = 'red')  
}
phi_m = rowMeans(post_phi[,burnin:maxiter])

# Zero-inflation
for(k in 1:K){
  plot(1:maxiter, post_p_aux[k,], type = 'l', main = paste('State',k,'zero-inflation'),
       ylab = bquote(p[.(k)]), xlab = 'Iteration')
  abline(h = zip[k], col = 'red')  
}
p_aux_m = rowMeans(post_p_aux[,burnin:maxiter])

# Prob of initial state
for(k in 1:K){
  plot(1:maxiter, post_pi[k,], type = 'l', main = paste('Prob. initial state is ',k),
       ylab = bquote(pi[.(k)]), xlab = 'Iteration')
  abline(h = pi[k], col = 'red')  
}

# Transition probability coefficients
par(mfrow = c(K, K-1))
for(cp in 1:p){
  for(k1 in 1:K){
   for(k2 in 1:(K-1)){
     posts = sapply(post_beta, function(x) x[k1,k2,cp])
     plot(1:maxiter, posts, type = 'l', xlab = '', ylab = '', main = bquote(paste("Covariate ", .(cp), " - ", beta[.(k1)][.(k2)])))
     abline(h = beta[k1,k2,cp], col = 'red')
   }
 }
}

# Number of nonzero TP regression coefficients in model
num_vars = rep(NA, maxiter)
for(iter in 1:maxiter){
  num_vars[iter] = sum(post_gamma_2[[iter]])
}
par(mfrow = c(1,1))
plot(1:maxiter, num_vars, xlab = '', ylab = '', main = '# TP coefficients included', type = 'l', cex = 0.5, ylim = c(0, K * (K-1) * p))
abline(h = sum(beta[,1:(K-1),] != 0), col = 'blue') # number of true nonzeros

# TP regression coefficients MPPI
# Note: Dots represent true inclusion/exclusion, red line is 0.5 MPPI inclusion critera
ppi2 = array(0, c(K, K-1, p))
for(iter in burnin:maxiter){
  ppi2 = ppi2 + post_gamma_2[[iter]]
}
ppi2 = ppi2/length(burnin:maxiter)

par(mfrow = c(K, K-1))
for(k1 in 1:K){
  for(k2 in 1:(K-1)){
    plot(1:p, ppi2[k1,k2,], ylim = c(0,1), type = 'h', xlab = 'Covariate', ylab = 'PPI', main = paste(k1,'->',k2,'transition coefficient inclusion'))
    abline(h = 0.5, col = 'red')
    points(1:p, (beta[k1,k2,] != 0), pch = 19)
  }
}

# NB regression coefficients
rho_m = matrix(NA, nrow = K, ncol = p)
par(mfrow = c(K, 1))
for(cp in 1:p){
  for(k in 1:K){
    posts = sapply(post_rho, function(x) x[k,cp])
    plot(1:maxiter, posts, type = 'l', xlab = '', ylab = '', main = bquote(paste('Covariate ', .(cp), ' State ', .(k))))
    abline(h = rho[k,cp], col = 'red')
    rho_m[k,cp] = mean(posts[burnin:maxiter])
  }
}

# Number of nonzero NB regression coefficients in model
num_vars = matrix(NA, K, maxiter)
for(iter in 1:maxiter){
  num_vars[,iter] = rowSums(post_gamma_1[[iter]])
}
for(k in 1:K){
  plot(1:maxiter, num_vars[k,], xlab = '', ylab = '', main = bquote(paste('State ',.(k))), type = 'l', ylim = c(0, p))
  abline(h = sum(rho[k,] != 0), col = 'blue') # number of true nonzeros
}

# NB regression coefficients MPPI
ppi1 = matrix(0, K, p)
for(iter in burnin:maxiter){
  ppi1 = ppi1 + post_gamma_1[[iter]]
}
ppi1 = ppi1/length(burnin:maxiter)

par(mfrow = c(K, 1))
for(k in 1:K){
  plot(1:p, ppi1[k,], ylim = c(0,1), type = "h", xlab = 'Covariate', ylab = 'PPI', main = bquote(paste('State ', .(k),' NB coefficient inclusion')))
  abline(h = 0.5, col = 'red')
  points(1:p, (rho[k,] != 0), pch = 19)
}

# Plot inference
layout(matrix(c(1,1,1,1,1,1,2,2), nrow = 8, ncol = 1))
for(pat in 1:N){
  plot(1:Ti[pat], Y[[pat]], pch = 19, main = paste('Patient',pat), ylab = 'Counts', xlab = 'Days')
  post_mode_xi = apply(post_xi[[pat]], 2, which.max)
  eta = 1 / (1 + exp(rowSums(X[[pat]] * rho_m[post_mode_xi,])))
  mu_inferred = (1 - eta) * phi_m[post_mode_xi] / eta
  lines(mu_inferred) # Inferred mean process
  
  # Now plot most likely sequence of states as posterior mode
  # Low risk = white, Moderate risk = yellow, High risk = red
  plot(c(0, Ti[pat]), c(0, 1), type= "n", yaxt = 'n', xlab = '', main = 'States', ylab = '') 
  starts = suppressWarnings(c(which(post_mode_xi != c(0, post_mode_xi)), Ti[pat]))
  cols = adjustcolor(c('white', 'yellow', 'red'), alpha.f = 0.5)
  for(ind in 1:(length(starts)-1)){
    start = starts[ind]
    end = starts[ind+1]
    rect(start, 0.1, end, 0.9, col=cols[post_mode_xi[start:end]], border = 'black')
  }
}
