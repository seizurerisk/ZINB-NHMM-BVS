# ZINB-NHMM-BVS  

Source code accompanying the paper "Bayesian non-homogeneous hidden Markov model with variable selection for investigating drivers of seizure risk cycling" by Wang et al.
ZINB-NHMM-BVS is a hidden Markov model written in R/C++ designed for unsupervised clustering of zero-inflated seizure count data. 
This folder contains code for the toy example, and code to replicate all simulation studies. Please see below for instructions on how to run the simulations.

## Instructions for decrypting source files

To request the decryption password, please complete the request form at https://forms.gle/hc8UHsB3bSdisQX27.
Install the R package `encryptr`. 
Run the code in `source_file_decryption.R` to decrypt all source files in the `toy_example` and `simulation_code` folders.
When prompted, enter the decryption password. 

## Instructions for `toy_example` folder

The `toy_example` folder contains code for running a toy example using our model. Below are the contents.
The R packages required for running each simulation are listed at the top of `main.R`.

1. `NBMCMC.R` contains the function to run the model.
2. `FB_SourceFunctions.cpp` contains helper functions to run the Forward-Backward algorithm for sampling the latent states.
3. `PG_SourceFunctions.R` contains a helper function to perform the Polya-Gamma data augmentation step for the transition probability regression coefficients.  
4. `main.R` is the main script for running a toy example with data and hyperparameters set as in Sections 3.1 and 3.2. Run within source folder.  

## Instructions for `simulation_code` folder

The `simulation_code` folder contains code to reproduce all simulation studies. 
The folder `Source Files` contains necessary functions for running all the simulations; please put them in the same folder as the R files. 
Finally, the R packages required for running each simulation are listed at the top of the files.
Below are descriptions of the files, including the location of the relevant results in the main text or supplement. 

1. Sim_1_scalability.R -- Section 3.3, Scalability investigation
2. Sim_2_sensitivity.R -- Tables 1 and 2, ZINB-NHMM-BVS Sensitivity analysis
3. Sim_3_model_selection.R -- Table 3, Model selection investigation
4. Sim_4_Poisson_ZINB.R -- Tables 4 and 5, Poisson study ZINB-NHMM-BVS performance
5. Sim_5_Poisson_ASAEM_AIC.R -- Tables 4 and 5, Poisson study ASA-EM, AIC performance
6. Sim_6_Poisson_ASAEM_BIC.R -- Tables 4 and 5, Poisson study ASA-EM, BIC performance
7. Sim_7_model_selection_AIC_BIC.R -- Table 3, Model selection with AIC/BIC
8. Sim_8_Poisson_ZINB_AIC_BIC.R -- Tables 4 and 5, Poisson study ZINB, AIC/BIC performance
9. Sim_S1_ZINB-NHMM-BVS.R -- Tables S3, S4, and S5, Posterior inference for ZINB-NHMM-BVS
10. Sim_S2_effect_sizes.R -- Table S6, Effect size investigation

### Authors  

Emily T. Wang, Sharon Chiang, Zulfi Haneef, Vikram R. Rao, Robert Moss, and Marina Vannucci  